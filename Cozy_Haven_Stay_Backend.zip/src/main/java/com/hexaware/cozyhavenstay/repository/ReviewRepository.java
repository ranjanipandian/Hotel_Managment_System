package com.hexaware.cozyhavenstay.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hexaware.cozyhavenstay.entities.Review;

public interface ReviewRepository extends JpaRepository<Review, Long> {

	List<Review> findByHotelId(Long hotelId);

	List<Review> findByUserId(Long userId);
	
	@Query("SELECT r FROM Review r WHERE r.hotel.owner.id = :ownerId")
	List<Review> findByOwnerId(@Param("ownerId") Long ownerId);

}
