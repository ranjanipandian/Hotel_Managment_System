package com.hexaware.cozyhavenstay.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.cozyhavenstay.entities.Room;

public interface RoomRepository extends JpaRepository<Room, Long> {
	List<Room> findByHotelId(Long hotelId);

	List<Room> findByRoomType(String roomType);

	List<Room> findByPriceBetween(double minPrice, double maxPrice);

	List<Room> findByIsAvailable(boolean isAvailable);

	List<Room> findByHotelIdAndIsAvailable(Long hotelId, boolean isAvailable);

	List<Room> findByHotelOwnerId(Long ownerId);

}