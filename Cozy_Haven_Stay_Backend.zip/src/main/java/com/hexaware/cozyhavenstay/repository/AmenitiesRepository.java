package com.hexaware.cozyhavenstay.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.cozyhavenstay.entities.Amenities;

public interface AmenitiesRepository extends JpaRepository<Amenities, Long> {
	List<Amenities> findByHotelId(Long hotelId);

	List<Amenities> findByHotelOwnerId(Long ownerId);
}
