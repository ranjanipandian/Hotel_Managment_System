package com.hexaware.cozyhavenstay.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hexaware.cozyhavenstay.entities.Payment;

import jakarta.transaction.Transactional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
	Optional<Payment> findByTransactionId(String transactionId);

	List<Payment> findByStatus(boolean status);
	
	List<Payment> findByBooking_User_Id(Long userId);

	@Transactional
	@Modifying
	@Query("DELETE FROM Payment p WHERE p.booking.id IN :bookingIds")
	void deleteByBookingIds(List<Long> bookingIds);
	
	//custom JPQL query
	@Query("SELECT p FROM Payment p WHERE p.booking.room.hotel.owner.id = :ownerId")
	List<Payment> findPaymentsByOwnerId(@Param("ownerId") Long ownerId);

}
