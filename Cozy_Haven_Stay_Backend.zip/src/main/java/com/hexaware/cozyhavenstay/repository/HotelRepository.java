package com.hexaware.cozyhavenstay.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hexaware.cozyhavenstay.entities.Hotel;

public interface HotelRepository extends JpaRepository<Hotel, Long> {

    @Query("SELECT h FROM Hotel h WHERE LOWER(h.city) = LOWER(:city)")
    List<Hotel> findByCityIgnoreCase(@Param("city") String city);

    Optional<Hotel> findByNameAndLocationIgnoreCase(String name, String location);

    List<Hotel> findByOwnerId(Long ownerId);
}
