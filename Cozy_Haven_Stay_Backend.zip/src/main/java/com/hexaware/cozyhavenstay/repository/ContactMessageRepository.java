package com.hexaware.cozyhavenstay.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.cozyhavenstay.entities.ContactMessage;

public interface ContactMessageRepository extends JpaRepository<ContactMessage, Long> {
	
}
