package com.hexaware.cozyhavenstay.repository;

import com.hexaware.cozyhavenstay.entities.Booking;

import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface BookingRepository extends JpaRepository<Booking, Long> {

	//find bookings id by user id
	
	@Query("SELECT b.id FROM Booking b WHERE b.user.id = :userId")
	List<Long> findIdsByUserId(@Param("userId") Long userId);

	//delete bookings by user id
	
	@Transactional
	@Modifying
	@Query("DELETE FROM Booking b WHERE b.user.id = :userId")
	void deleteByUserId(@Param("userId") Long userId);

	//find by hotel id
	
	List<Booking> findByRoom_Hotel_Id(Long hotelId);

	//checks whether cancelled
	
	List<Booking> findByIsCancelled(boolean isCancelled);

	//find by hotel owner
	
	List<Booking> findByRoom_Hotel_OwnerId(Long ownerId);

	//finds a non-cancelled booking for a specific room to prevent double booking
	
	Optional<Booking> findByRoomIdAndIsCancelledFalse(Long roomId);

	//finds if a user has an non-cancelled booking for a room 
	
	Optional<Booking> findByRoomIdAndUserIdAndIsCancelledFalse(Long roomId, Long userId);

	//finds overlapping bookings 
	
	@Query("SELECT b FROM Booking b " + "WHERE b.room.id = :roomId " + "AND b.user.id = :userId "
			+ "AND b.isCancelled = false " + "AND (b.checkInDate < :checkoutDate AND b.checkoutDate > :checkInDate)")
	List<Booking> findOverlappingBookingsForUser(@Param("roomId") Long roomId, @Param("userId") Long userId,
			@Param("checkInDate") LocalDate checkInDate, @Param("checkoutDate") LocalDate checkoutDate);

	//finds booking with room and hotel
	
	@Query("SELECT b FROM Booking b JOIN FETCH b.room r JOIN FETCH r.hotel WHERE b.id = :id")
	Optional<Booking> findByIdWithRoomAndHotel(@Param("id") Long id);
} 