package com.hexaware.cozyhavenstay.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.hexaware.cozyhavenstay.entities.Image;

public interface ImageRepository extends JpaRepository<Image, Long> {
	List<Image> findByHotelId(Long hotelId);

	List<Image> findByRoomId(Long roomId);
}
