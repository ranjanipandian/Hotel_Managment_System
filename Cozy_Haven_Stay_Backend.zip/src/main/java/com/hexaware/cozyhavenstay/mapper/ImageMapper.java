package com.hexaware.cozyhavenstay.mapper;

import com.hexaware.cozyhavenstay.dto.ImageDTO;
import com.hexaware.cozyhavenstay.entities.Hotel;
import com.hexaware.cozyhavenstay.entities.Image;

public class ImageMapper {

    public static ImageDTO toDTO(Image image) {
        if (image == null) return null;

        ImageDTO dto = new ImageDTO();
        dto.setId(image.getId());
        dto.setHotelId(image.getHotel() != null ? image.getHotel().getId() : null);
        dto.setFileName(image.getFileName());
        dto.setDescription(image.getDescription());
        dto.setUrl(image.getUrl());

        return dto;
    }

    public static Image toEntity(ImageDTO dto, Hotel hotel) {
        if (dto == null) return null;

        Image image = new Image();
        image.setId(dto.getId());
        image.setHotel(hotel);
        image.setFileName(dto.getFileName());
        image.setDescription(dto.getDescription());
        image.setUrl(dto.getUrl());

        return image;
    }
}
