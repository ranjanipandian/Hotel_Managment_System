package com.hexaware.cozyhavenstay.mapper;

import com.hexaware.cozyhavenstay.dto.PaymentDTO;
import com.hexaware.cozyhavenstay.entities.Booking;
import com.hexaware.cozyhavenstay.entities.Payment;

public class PaymentMapper {

	public static PaymentDTO toDTO(Payment payment) {
		PaymentDTO dto = new PaymentDTO();
		dto.setId(payment.getId());
		dto.setTransactionId(payment.getTransactionId());
		dto.setTotalAmount(payment.getTotalAmount());
		dto.setPaymentDate(payment.getPaymentDate());
		dto.setStatus(payment.isStatus());
		dto.setBookingId(payment.getBooking() != null ? payment.getBooking().getId() : null);
		dto.setPaymentMode(payment.getPaymentMode());
		return dto;
	}

	public static Payment toEntity(PaymentDTO dto, Booking booking) {
		Payment payment = new Payment();
		payment.setId(dto.getId());
		payment.setTransactionId(dto.getTransactionId());
		payment.setTotalAmount(dto.getTotalAmount());
		payment.setPaymentDate(dto.getPaymentDate());
		payment.setStatus(dto.isStatus());
		payment.setPaymentMode(dto.getPaymentMode());
		payment.setBooking(booking);
		return payment;
	}
}
