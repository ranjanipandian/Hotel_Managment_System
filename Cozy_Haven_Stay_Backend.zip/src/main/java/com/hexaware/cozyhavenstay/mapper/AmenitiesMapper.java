package com.hexaware.cozyhavenstay.mapper;

import com.hexaware.cozyhavenstay.dto.AmenitiesDTO;
import com.hexaware.cozyhavenstay.entities.Amenities;
import com.hexaware.cozyhavenstay.entities.Hotel;

public class AmenitiesMapper {

    public static AmenitiesDTO toDTO(Amenities amenity) {
        AmenitiesDTO dto = new AmenitiesDTO();
        dto.setId(amenity.getId());
        dto.setName(amenity.getName());
        dto.setHotelId(amenity.getHotel() != null ? amenity.getHotel().getId() : null);
        dto.setHotelName(amenity.getHotel() != null ? amenity.getHotel().getName() : null); 
        dto.setDescription(amenity.getDescription());
        return dto;
    }

    public static Amenities toEntity(AmenitiesDTO dto, Hotel hotel) {
        Amenities amenity = new Amenities();
        amenity.setId(dto.getId());
        amenity.setName(dto.getName());
        amenity.setDescription(dto.getDescription());
        amenity.setHotel(hotel);
        return amenity;
    }
}
