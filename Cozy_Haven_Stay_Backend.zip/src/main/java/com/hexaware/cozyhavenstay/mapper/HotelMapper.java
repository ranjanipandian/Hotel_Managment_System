package com.hexaware.cozyhavenstay.mapper;

import com.hexaware.cozyhavenstay.dto.HotelDTO;
import com.hexaware.cozyhavenstay.entities.Hotel;
import com.hexaware.cozyhavenstay.entities.User;

public class HotelMapper {

    public static Hotel fromDTO(HotelDTO dto, User owner) {
        Hotel hotel = new Hotel();
        hotel.setId(dto.getId());
        hotel.setName(dto.getName());
        hotel.setLocation(dto.getLocation());
        hotel.setCity(dto.getCity());
        hotel.setPhoneno(dto.getPhoneno());
        hotel.setOwner(owner);
        hotel.setImageUrl(dto.getImageUrl()); 
        return hotel;
    }

    public static HotelDTO toDTO(Hotel hotel) {
        HotelDTO dto = new HotelDTO();
        dto.setId(hotel.getId());
        dto.setName(hotel.getName());
        dto.setLocation(hotel.getLocation());
        dto.setCity(hotel.getCity());
        dto.setPhoneno(hotel.getPhoneno());

        if (hotel.getOwner() != null) {
            dto.setOwnerId(hotel.getOwner().getId());
        }
        dto.setImageUrl(hotel.getImageUrl());

        return dto;
    }
}
