package com.hexaware.cozyhavenstay.mapper;

import org.springframework.stereotype.Component;

import com.hexaware.cozyhavenstay.dto.UserDTO;
import com.hexaware.cozyhavenstay.entities.User;
import com.hexaware.cozyhavenstay.enums.Role;

@Component
public class UserMapper {

    public static UserDTO toDTO(User user) {
        if (user == null) return null;

        UserDTO dto = new UserDTO();
        dto.setId(user.getId());
        dto.setUserName(user.getName());
        dto.setEmail(user.getEmail());
        dto.setPhoneNumber(user.getPhoneNumber());
        dto.setRole(user.getRole() != null ? user.getRole().toString() : null);

        return dto;
    }

    public static User toEntity(UserDTO dto) {
        if (dto == null) return null;

        User user = new User();
        user.setId(dto.getId());
        user.setName(dto.getUserName());
        user.setEmail(dto.getEmail());
        user.setPhoneNumber(dto.getPhoneNumber());

        if (dto.getRole() != null) {
            try {
                user.setRole(Role.valueOf(dto.getRole().toUpperCase())); 
            } catch (IllegalArgumentException e) {
                user.setRole(null); 
            }
        }

        return user;
    }
}
