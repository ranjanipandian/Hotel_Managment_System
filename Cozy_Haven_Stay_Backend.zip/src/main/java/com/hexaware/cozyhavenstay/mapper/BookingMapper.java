package com.hexaware.cozyhavenstay.mapper;

import com.hexaware.cozyhavenstay.dto.BookingDTO;
import com.hexaware.cozyhavenstay.entities.Booking;
import com.hexaware.cozyhavenstay.entities.Room;
import com.hexaware.cozyhavenstay.entities.User;

public class BookingMapper {

    public static Booking toEntity(BookingDTO dto, User user, Room room) {
        Booking booking = new Booking();
        booking.setId(dto.getId());
        booking.setNoOfRooms(dto.getNoOfRooms());
        booking.setNoOfAdults(dto.getNoOfAdults());
        booking.setNoOfChildren(dto.getNoOfChildren());
        booking.setCheckInDate(dto.getCheckInDate());
        booking.setCheckoutDate(dto.getCheckoutDate());
        booking.setTotalAmount(dto.getTotalAmount());
        booking.setCancelled(dto.isCancelled());
        booking.setCancellationDate(dto.getCancellationDate());
        booking.setCancellationReason(dto.getCancellationReason());
        booking.setUser(user);
        booking.setRoom(room);
        return booking;
    }

    public static BookingDTO toDTO(Booking booking) {
        BookingDTO dto = new BookingDTO();
        dto.setId(booking.getId());
        dto.setNoOfRooms(booking.getNoOfRooms());
        dto.setNoOfAdults(booking.getNoOfAdults());
        dto.setNoOfChildren(booking.getNoOfChildren());
        dto.setCheckInDate(booking.getCheckInDate());
        dto.setCheckoutDate(booking.getCheckoutDate());
        dto.setTotalAmount(booking.getTotalAmount());
        dto.setCancelled(booking.isCancelled());
        dto.setCancellationDate(booking.getCancellationDate());
        dto.setCancellationReason(booking.getCancellationReason());
        dto.setUserId(booking.getUser().getId());
        dto.setRoomId(booking.getRoom().getId());

        if (booking.getRoom() != null && booking.getRoom().getHotel() != null) {
            dto.setHotelName(booking.getRoom().getHotel().getName());
        }

        return dto;
    }
}
