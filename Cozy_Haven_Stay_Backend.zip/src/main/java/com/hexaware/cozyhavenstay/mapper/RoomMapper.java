package com.hexaware.cozyhavenstay.mapper;

import com.hexaware.cozyhavenstay.dto.RoomDTO;
import com.hexaware.cozyhavenstay.entities.Hotel;
import com.hexaware.cozyhavenstay.entities.Room;

public class RoomMapper {

    public static RoomDTO toDTO(Room room) {
        RoomDTO dto = new RoomDTO();
        dto.setId(room.getId());
        dto.setRoomType(room.getRoomType());
        dto.setBedType(room.getBedType());
        dto.setPrice(room.getPrice());
        dto.setAccomodate(room.getAccomodate());
        dto.setIsAc(room.isAc());
        dto.setIsAvailable(room.isAvailable());
        dto.setHotelId(room.getHotel() != null ? room.getHotel().getId() : null);
        return dto;
    }

    public static Room toEntity(RoomDTO dto, Hotel hotel) {
        Room room = new Room();
        room.setId(dto.getId());
        room.setRoomType(dto.getRoomType());
        room.setBedType(dto.getBedType());
        room.setPrice(dto.getPrice());
        room.setAccomodate(dto.getAccomodate());
        room.setAc(dto.getIsAc());
        room.setAvailable(dto.getIsAvailable());
        room.setHotel(hotel);  
        return room;
    }
}
