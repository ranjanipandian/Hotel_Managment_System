package com.hexaware.cozyhavenstay.mapper;

import com.hexaware.cozyhavenstay.dto.ReviewDTO;
import com.hexaware.cozyhavenstay.entities.Hotel;
import com.hexaware.cozyhavenstay.entities.Review;
import com.hexaware.cozyhavenstay.entities.User;

public class ReviewMapper {

    public static ReviewDTO toDTO(Review review) {
        ReviewDTO dto = new ReviewDTO();
        dto.setId(review.getId());
        dto.setComment(review.getComment());
        dto.setRating(review.getRating());
        dto.setUserId(review.getUser() != null ? review.getUser().getId() : null);
        dto.setHotelId(review.getHotel() != null ? review.getHotel().getId() : null);

        dto.setGuestName(review.getUser() != null ? review.getUser().getName() : "Anonymous");
        dto.setHotelName(review.getHotel() != null ? review.getHotel().getName() : "Unknown Hotel");

        return dto;
    }

    public static Review toEntity(ReviewDTO dto, User user, Hotel hotel) {
        Review review = new Review();
        review.setId(dto.getId());
        review.setComment(dto.getComment());
        review.setRating(dto.getRating());
        review.setUser(user);
        review.setHotel(hotel);
        return review;
    }
}
