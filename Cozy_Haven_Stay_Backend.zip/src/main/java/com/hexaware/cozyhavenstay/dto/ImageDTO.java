package com.hexaware.cozyhavenstay.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class ImageDTO {
    private Long id;

    @NotNull(message = "Hotel ID is required")
    private Long hotelId;

    @Size(max = 255, message = "File name must not exceed 255 characters")
    private String fileName;

    @Size(max = 255, message = "Description must not exceed 255 characters")
    private String description;

    @Size(max = 500, message = "Image URL must not exceed 500 characters")
    private String url;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }

    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    public String getUrl() {
        return url;
    }
    public void setUrl(String url) {
        this.url = url;
    }
}
