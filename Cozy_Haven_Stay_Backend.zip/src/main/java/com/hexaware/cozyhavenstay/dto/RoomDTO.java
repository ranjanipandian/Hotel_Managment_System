package com.hexaware.cozyhavenstay.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

public class RoomDTO {
    private Long id;

    @NotBlank(message = "Room type must not be blank")
    @Size(max = 50, message = "Room type must be at most 50 characters")
    private String roomType;

    @NotBlank(message = "Bed type must not be blank")
    @Size(max = 50, message = "Bed type must be at most 50 characters")
    private String bedType;

    @Positive(message = "Price must be positive")
    private double price;

    @Min(value = 1, message = "Accommodate must be at least 1")
    private int accomodate;

    @NotNull(message = "AC availability must be specified")
    private boolean isAc;

    @NotNull(message = "Availability must be specified")
    private boolean isAvailable;

    @NotNull(message = "Hotel ID must be specified")
    private Long hotelId;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public String getBedType() {
        return bedType;
    }

    public void setBedType(String bedType) {
        this.bedType = bedType;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getAccomodate() {
        return accomodate;
    }

    public void setAccomodate(int accomodate) {
        this.accomodate = accomodate;
    }

    public boolean getIsAc() {
        return isAc;
    }

    public void setIsAc(boolean isAc) {
        this.isAc = isAc;
    }

    public boolean getIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    public Long getHotelId() {
        return hotelId;
    }

    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
}
