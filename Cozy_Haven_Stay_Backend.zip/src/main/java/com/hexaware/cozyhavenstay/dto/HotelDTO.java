package com.hexaware.cozyhavenstay.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class HotelDTO {
	private Long id;

	@NotBlank(message = "Hotel name is required")
	private String name;

	@NotBlank(message = "City is required")
	private String city;

	@NotBlank(message = "Location is required")
	private String location;

	@NotNull(message = "Owner ID is required")
	private Long ownerId;

	@NotBlank(message = "Phone number is required")
	@Pattern(regexp = "\\+?[0-9\\- ]{7,15}", message = "Phone number is invalid")
	private String phoneno;

	private String imageUrl;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Long getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Long ownerId) {
		this.ownerId = ownerId;
	}

	public String getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
}
