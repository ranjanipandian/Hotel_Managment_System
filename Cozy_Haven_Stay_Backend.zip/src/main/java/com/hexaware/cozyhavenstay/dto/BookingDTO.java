package com.hexaware.cozyhavenstay.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

public class BookingDTO {
	private Long id;

	@Min(value = 1, message = "Number of rooms must be at least 1")
	private int noOfRooms;

	@Min(value = 1, message = "Number of adults must be at least 1")
	private int noOfAdults;

	@Min(value = 0, message = "Number of children cannot be negative")
	private int noOfChildren;

	@NotNull(message = "Check-in date cannot be null")
	private LocalDate checkInDate;

	@NotNull(message = "Checkout date cannot be null")
	private LocalDate checkoutDate;

	@PositiveOrZero(message = "Total amount must be zero or positive")
	private double totalAmount;

	private boolean isCancelled;
	private LocalDate cancellationDate;
	private String cancellationReason;

	@NotNull(message = "User ID must be provided")
	private Long userId;

	@NotNull(message = "Room ID must be provided")
	private Long roomId;

	private String hotelName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getNoOfRooms() {
		return noOfRooms;
	}

	public void setNoOfRooms(int noOfRooms) {
		this.noOfRooms = noOfRooms;
	}

	public int getNoOfAdults() {
		return noOfAdults;
	}

	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	public int getNoOfChildren() {
		return noOfChildren;
	}

	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	public LocalDate getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(LocalDate checkInDate) {
		this.checkInDate = checkInDate;
	}

	public LocalDate getCheckoutDate() {
		return checkoutDate;
	}

	public void setCheckoutDate(LocalDate checkoutDate) {
		this.checkoutDate = checkoutDate;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public boolean isCancelled() {
		return isCancelled;
	}

	public void setCancelled(boolean isCancelled) {
		this.isCancelled = isCancelled;
	}

	public LocalDate getCancellationDate() {
		return cancellationDate;
	}

	public void setCancellationDate(LocalDate cancellationDate) {
		this.cancellationDate = cancellationDate;
	}

	public String getCancellationReason() {
		return cancellationReason;
	}

	public void setCancellationReason(String cancellationReason) {
		this.cancellationReason = cancellationReason;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getRoomId() {
		return roomId;
	}

	public void setRoomId(Long roomId) {
		this.roomId = roomId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	@AssertTrue(message = "Checkout date must be after check-in date")
	public boolean isCheckOutAfterCheckIn() {
		if (checkInDate == null || checkoutDate == null) {
			return true;
		}
		return checkoutDate.isAfter(checkInDate);
	}
}
