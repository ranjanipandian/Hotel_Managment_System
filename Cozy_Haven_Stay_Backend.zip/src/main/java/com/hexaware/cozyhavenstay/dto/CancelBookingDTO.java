package com.hexaware.cozyhavenstay.dto;

import jakarta.validation.constraints.NotBlank;

public class CancelBookingDTO {
	@NotBlank(message = "Cancellation reason must not be blank")
    private String reason;

    public CancelBookingDTO() {
    }

    public CancelBookingDTO(String reason) {
        this.reason = reason;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
