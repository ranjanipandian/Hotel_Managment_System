package com.hexaware.cozyhavenstay.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class AmenitiesDTO {
	private Long id;

	@NotBlank(message = "Amenity name cannot be blank")
	private String name;

	@NotNull(message = "Hotel ID must be specified")
	private Long hotelId;

	@NotBlank(message = "Description cannot be blank")
	private String description;

	private String hotelName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getHotelId() {
		return hotelId;
	}

	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
}
