package com.hexaware.cozyhavenstay.exception;

public class PaymentFailedException extends RuntimeException{
	public PaymentFailedException(String message) {
        super(message);
    }
}
