package com.hexaware.cozyhavenstay.entities;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

@Entity
@Table(name = "bookings")
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Min(value = 1, message = "Number of rooms must be at least 1")
	private int noOfRooms;

	@Min(value = 1, message = "Number of adults must be at least 1")
	private int noOfAdults;

	@Min(value = 0, message = "Number of children cannot be negative")
	private int noOfChildren;

	@NotNull(message = "Check-in date cannot be null")
	private LocalDate checkInDate;

	@NotNull(message = "Checkout date cannot be null")
	private LocalDate checkoutDate;

	@PositiveOrZero(message = "Total amount must be zero or positive")
	private double totalAmount;

	private boolean isCancelled;

	private LocalDate cancellationDate;

	private String cancellationReason;

	@ManyToOne
	@JsonIgnoreProperties({"bookings", "reviews"})
	@JoinColumn(name = "userId", nullable = false)
	@NotNull(message = "User must be specified")
	private User user;

	@ManyToOne
	@JsonIgnoreProperties({"room", "owner"})
	@JoinColumn(name = "roomId", nullable = false)
	@NotNull(message = "Room must be specified")
	private Room room;

	@OneToOne(mappedBy = "booking", cascade = CascadeType.ALL)
	private Payment payment;

	public Booking() {
	}

	public Booking(Long id, int noOfRooms, int noOfAdults, int noOfChildren, LocalDate checkInDate,
			LocalDate checkoutDate, double totalAmount, boolean isCancelled, LocalDate cancellationDate,
			String cancellationReason, User user, Room room, Payment payement) {
		super();
		this.id = id;
		this.noOfRooms = noOfRooms;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.checkInDate = checkInDate;
		this.checkoutDate = checkoutDate;
		this.totalAmount = totalAmount;
		this.isCancelled = isCancelled;
		this.cancellationDate = cancellationDate;
		this.cancellationReason = cancellationReason;
		this.user = user;
		this.room = room;
		this.payment = payment;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getNoOfRooms() {
		return noOfRooms;
	}

	public void setNoOfRooms(int noOfRooms) {
		this.noOfRooms = noOfRooms;
	}

	public int getNoOfAdults() {
		return noOfAdults;
	}

	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	public int getNoOfChildren() {
		return noOfChildren;
	}

	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	public LocalDate getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(LocalDate checkInDate) {
		this.checkInDate = checkInDate;
	}

	public LocalDate getCheckoutDate() {
		return checkoutDate;
	}

	public void setCheckoutDate(LocalDate checkoutDate) {
		this.checkoutDate = checkoutDate;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public boolean isCancelled() {
		return isCancelled;
	}

	public void setCancelled(boolean isCancelled) {
		this.isCancelled = isCancelled;
	}

	public LocalDate getCancellationDate() {
		return cancellationDate;
	}

	public void setCancellationDate(LocalDate cancellationDate) {
		this.cancellationDate = cancellationDate;
	}

	public String getCancellationReason() {
		return cancellationReason;
	}

	public void setCancellationReason(String cancellationReason) {
		this.cancellationReason = cancellationReason;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}
}
