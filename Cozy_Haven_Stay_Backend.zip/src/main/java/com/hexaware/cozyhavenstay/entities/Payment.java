package com.hexaware.cozyhavenstay.entities;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

@Entity
@Table(name = "payments")
public class Payment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank(message = "Transaction ID cannot be blank")
	private String transactionId;

	@PositiveOrZero(message = "Total amount must be zero or positive")
	private double totalAmount;

	@NotNull(message = "Payment date cannot be null")
	private LocalDateTime paymentDate;

	private boolean status;

	@NotBlank(message = "Payment mode cannot be blank")
	private String paymentMode;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "bookingId", nullable = false)
	@NotNull(message = "Booking must be specified")
	private Booking booking;

	public Payment() {
	}

	public Payment(Long id, String transactionId, double totalAmount, LocalDateTime paymentDate,
				   boolean status, String paymentMode, Booking booking) {
		this.id = id;
		this.transactionId = transactionId;
		this.totalAmount = totalAmount;
		this.paymentDate = paymentDate;
		this.status = status;
		this.paymentMode = paymentMode;
		this.booking = booking;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public LocalDateTime getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(LocalDateTime paymentDate) {
		this.paymentDate = paymentDate;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public Booking getBooking() {
		return booking;
	}

	public void setBooking(Booking booking) {
		this.booking = booking;
	}
}
