package com.hexaware.cozyhavenstay.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "hotels")
public class Hotel {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank(message = "Hotel name cannot be blank")
	private String name;

	@NotBlank(message = "City is required")
	private String city;

	@NotBlank(message = "Location cannot be blank")
	private String location;

	@NotBlank(message = "Phone number cannot be blank")
	@Column(name = "phoneno")
	@Pattern(regexp = "^\\+?[0-9\\- ]{7,15}$", message = "Invalid phone number format")
	private String Phoneno;

	@Size(max = 2000, message = "Description cannot exceed 2000 characters")
	private String description;

	@Column(name = "image_url")
	private String imageUrl; 

	@ManyToOne
	@JsonIgnoreProperties({ "bookings", "reviews" })
	@JoinColumn(name = "ownerId", nullable = false)
	@NotNull(message = "Owner must be specified")
	private User owner;

	@OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL)
	private List<Room> room;

	@OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL)
	private List<Amenities> amenity;

	@OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL)
	private List<Review> review;

	@OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL)
	private List<Image> image;

	public Hotel() {
	}

	public Hotel(Long id, String name, String location, String phoneno, String city, String description, User owner,
			List<Room> room, List<Amenities> amenity, List<Review> review, List<Image> image) {
		this.id = id;
		this.name = name;
		this.location = location;
		this.Phoneno = phoneno;
		this.city = city;
		this.description = description;
		this.owner = owner;
		this.room = room;
		this.amenity = amenity;
		this.review = review;
		this.image = image;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getPhoneno() {
		return Phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.Phoneno = phoneno;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public User getOwner() {
		return owner;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}

	public List<Room> getRoom() {
		return room;
	}

	public void setRoom(List<Room> room) {
		this.room = room;
	}

	public List<Amenities> getAmenity() {
		return amenity;
	}

	public void setAmenity(List<Amenities> amenity) {
		this.amenity = amenity;
	}

	public List<Review> getReview() {
		return review;
	}

	public void setReview(List<Review> review) {
		this.review = review;
	}

	public List<Image> getImage() {
		return image;
	}

	public void setImage(List<Image> image) {
		this.image = image;
	}
}
