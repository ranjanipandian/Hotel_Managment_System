package com.hexaware.cozyhavenstay.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "reviews")
public class Review {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank(message = "Comment cannot be blank")
	@Size(max = 1000, message = "Comment can't exceed 1000 characters")
	private String comment;

	@Min(value = 1, message = "Rating must be at least 1")
	@Max(value = 5, message = "Rating cannot be more than 5")
	private int rating;

	@ManyToOne
	@JoinColumn(name = "userId", nullable = false)
	@NotNull(message = "User must be specified")
	private User user;

	@ManyToOne
	@JoinColumn(name = "hotelId", nullable = false)
	@NotNull(message = "Hotel must be specified")
	private Hotel hotel;

	public Review() {
	}

	public Review(Long id, String comment, int rating, User user, Hotel hotel) {
		super();
		this.id = id;
		this.comment = comment;
		this.rating = rating;
		this.user = user;
		this.hotel = hotel;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
}
