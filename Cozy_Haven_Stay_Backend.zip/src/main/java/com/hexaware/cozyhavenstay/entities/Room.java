package com.hexaware.cozyhavenstay.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "rooms")
public class Room {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank(message = "Room type must not be blank")
	@Size(max = 50, message = "Room type must be at most 50 characters")
	private String roomType;

	@NotBlank(message = "Bed type must not be blank")
	@Size(max = 50, message = "Bed type must be at most 50 characters")
	private String bedType;

	@Positive(message = "Price must be positive")
	private double price;

	@Min(value = 1, message = "Accomodate must be at least 1")
	private int accomodate;

	@Column(name = "is_ac", nullable = false)
	private boolean isAc;

	@Column(name = "is_available", nullable = false)
	private boolean isAvailable;

	@ManyToOne
	@JsonIgnoreProperties({"room", "owner"})
	@JoinColumn(name = "hotelId",nullable = false)
	@NotNull(message = "Hotel must not be null")
	private Hotel hotel;

	public Room() {
	}

	public Room(Long id, String roomType, String bedType, double price, int accomodate, Boolean isAc,
			Boolean isAvailable, Hotel hotel) {
		super();
		this.id = id;
		this.roomType = roomType;
		this.bedType = bedType;
		this.price = price;
		this.accomodate = accomodate;
		this.isAc = isAc;
		this.isAvailable = isAvailable;
		this.hotel = hotel;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getBedType() {
		return bedType;
	}

	public void setBedType(String bedType) {
		this.bedType = bedType;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getAccomodate() {
		return accomodate;
	}

	public void setAccomodate(int accomodate) {
		this.accomodate = accomodate;
	}

	public boolean isAc() {
		return isAc;
	}

	public void setAc(boolean isAc) {
		this.isAc = isAc;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
}
