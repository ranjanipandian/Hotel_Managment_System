package com.hexaware.cozyhavenstay.service;

import java.util.List;
import java.util.Optional;

import com.hexaware.cozyhavenstay.dto.HotelDTO;
import com.hexaware.cozyhavenstay.entities.Hotel;

public interface HotelService {
	Hotel saveHotel(HotelDTO hotelDTO);

	List<Hotel> getAllHotels();

	Optional<Hotel> findById(Long id);

	List<Hotel> findByCityIgnoreCase(String city);

	void deleteHotel(Long id);

	Hotel updateHotel(Long id, HotelDTO hotelDTO);

	List<Hotel> getHotelsByOwnerId(Long ownerId);
}
