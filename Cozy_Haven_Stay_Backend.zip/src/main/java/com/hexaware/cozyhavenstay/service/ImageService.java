package com.hexaware.cozyhavenstay.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import com.hexaware.cozyhavenstay.entities.Image;

public interface ImageService {
	Image saveImage(Image image);

	Optional<Image> getImageById(Long id);

	List<Image> getAllImages();

	List<Image> findByHotelId(Long hotelId);

	List<Image> findByRoomId(Long roomId);

	void deleteImage(Long id);

	void saveImageFile(MultipartFile file) throws IOException;
}
