package com.hexaware.cozyhavenstay.service;

import java.util.List;
import java.util.Optional;

import com.hexaware.cozyhavenstay.entities.User;

public interface UserService {
	User saveUser(User user);

	Optional<User> getUserById(Long id);

	List<User> getAllUsers();

	void deleteUser(Long id);

	User updateUser(Long id, User user);

	User findById(Long userId);

	User findByEmail(String email);

}
