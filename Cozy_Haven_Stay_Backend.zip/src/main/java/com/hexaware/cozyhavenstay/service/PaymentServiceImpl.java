package com.hexaware.cozyhavenstay.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.cozyhavenstay.entities.Payment;
import com.hexaware.cozyhavenstay.repository.PaymentRepository;

import jakarta.transaction.Transactional;

@Service
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	private PaymentRepository paymentRepository;

	public PaymentServiceImpl(PaymentRepository paymentRepository) {
		super();
		this.paymentRepository = paymentRepository;
	}

	@Override
	public Payment savePayment(Payment payment) {
		return paymentRepository.save(payment);
	}

	@Override
	public Optional<Payment> getPaymentById(Long id) {
		return paymentRepository.findById(id);
	}

	@Override
	public Optional<Payment> getPaymentByTransactionId(String transactionId) {
		return paymentRepository.findByTransactionId(transactionId);
	}

	@Override
	public List<Payment> getAllPayments() {
		return paymentRepository.findAll();
	}

	@Override
	public List<Payment> findByStatus(boolean status) {
		return paymentRepository.findByStatus(status);
	}

	@Override
	@Transactional
	public void deletePayment(Long id) {
		if (!paymentRepository.existsById(id)) {
			throw new RuntimeException("Payment with id " + id + " not found");
		}
		paymentRepository.deleteById(id);
	}
	
	@Override
	public List<Payment> findByUserId(Long userId) {
	    return paymentRepository.findByBooking_User_Id(userId);
	}
	@Override
    public List<Payment> findPaymentsByOwnerId(Long ownerId) {
        return paymentRepository.findPaymentsByOwnerId(ownerId);
    }

}
