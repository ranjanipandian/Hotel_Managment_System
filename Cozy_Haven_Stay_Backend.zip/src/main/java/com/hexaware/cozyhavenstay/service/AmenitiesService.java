package com.hexaware.cozyhavenstay.service;

import java.util.List;
import com.hexaware.cozyhavenstay.entities.Amenities;

public interface AmenitiesService {
	Amenities saveAmenity(Amenities amenity);

	List<Amenities> getAllAmenities();

	Amenities updateAmenity(Long id, Amenities amenity);

	boolean deleteAmenity(Long id);

	List<Amenities> getAmenitiesByHotel(Long hotelId);

	List<Amenities> getAmenitiesByOwnerId(Long ownerId);
}
