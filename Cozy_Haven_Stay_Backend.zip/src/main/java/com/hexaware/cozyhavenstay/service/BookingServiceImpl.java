package com.hexaware.cozyhavenstay.service;

import com.hexaware.cozyhavenstay.entities.Booking;
import com.hexaware.cozyhavenstay.exception.ResourceNotFoundException;
import com.hexaware.cozyhavenstay.repository.BookingRepository;

import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;

    public BookingServiceImpl(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    @Override
    public Booking saveBooking(Booking booking) {
        List<Booking> userOverlap = bookingRepository.findOverlappingBookingsForUser(
                booking.getRoom().getId(),
                booking.getUser().getId(),
                booking.getCheckInDate(),
                booking.getCheckoutDate());

        if (!userOverlap.isEmpty()) {
            throw new IllegalArgumentException("You have already booked this room for the selected dates.");
        }

        return bookingRepository.save(booking);
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    public Booking cancelBooking(Long id, String reason) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + id));

        if (booking.isCancelled()) {
            throw new IllegalStateException("Booking is already cancelled.");
        }

        booking.setCancelled(true);
        booking.setCancellationDate(LocalDate.now());
        booking.setCancellationReason(reason);

        return bookingRepository.save(booking);
    }

    @Override
    public Optional<Booking> getBookingByRoomIdAndIsCancelledFalse(Long roomId) {
        return bookingRepository.findByRoomIdAndIsCancelledFalse(roomId);
    }

    @Override
    public Booking getBookingById(Long id) {
        return bookingRepository.findByIdWithRoomAndHotel(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + id));
    }
    @Override
    public boolean deleteBooking(Long id) {
        if (!bookingRepository.existsById(id)) {
            return false;
        }
        bookingRepository.deleteById(id);
        return true;
    }
    
    @Override
    public List<Booking> getBookingsByOwnerId(Long ownerId) {
        return bookingRepository.findByRoom_Hotel_OwnerId(ownerId);
    }


}
