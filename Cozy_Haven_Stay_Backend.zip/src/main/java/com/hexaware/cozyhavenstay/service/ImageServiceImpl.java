package com.hexaware.cozyhavenstay.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hexaware.cozyhavenstay.entities.Image;
import com.hexaware.cozyhavenstay.repository.ImageRepository;

@Service
public class ImageServiceImpl implements ImageService {

    @Autowired
    private ImageRepository imageRepository;

    @Override
    public Image saveImage(Image image) {
        return imageRepository.save(image);
    }

    @Override
    public Optional<Image> getImageById(Long id) {
        return imageRepository.findById(id);
    }

    @Override
    public List<Image> getAllImages() {
        return imageRepository.findAll();
    }

    @Override
    public List<Image> findByHotelId(Long hotelId) {
        return imageRepository.findByHotelId(hotelId);
    }

    @Override
    public List<Image> findByRoomId(Long roomId) {
        return imageRepository.findByRoomId(roomId);
    }

    @Override
    public void deleteImage(Long id) {
        imageRepository.deleteById(id);
    }

    @Override
    public void saveImageFile(MultipartFile file) {
        Image image = new Image();
        image.setFileName(file.getOriginalFilename());

        String url = "https://your-server.com/images/" + file.getOriginalFilename();
        image.setUrl(url);

        image.setDescription("Image uploaded by owner");
        imageRepository.save(image);
    }
}
