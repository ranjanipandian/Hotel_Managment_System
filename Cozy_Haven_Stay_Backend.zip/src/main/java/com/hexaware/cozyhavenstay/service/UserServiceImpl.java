package com.hexaware.cozyhavenstay.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.cozyhavenstay.entities.User;
import com.hexaware.cozyhavenstay.mapper.UserMapper;
import com.hexaware.cozyhavenstay.repository.BookingRepository;
import com.hexaware.cozyhavenstay.repository.PaymentRepository;
import com.hexaware.cozyhavenstay.repository.ReviewRepository;
import com.hexaware.cozyhavenstay.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private final UserRepository userRepository;

	@Autowired
	private BookingRepository bookingRepository;

	@Autowired
	private PaymentRepository paymentRepository;
	
	@Autowired
	private ReviewRepository reviewRepository;

	@Autowired
	private UserMapper userMapper;

	public UserServiceImpl(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Override
	public User saveUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public Optional<User> getUserById(Long id) {
		return userRepository.findById(id);
	}

	@Override
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	@Override
	@Transactional
	public void deleteUser(Long userId) {
		List<Long> bookingIds = bookingRepository.findIdsByUserId(userId);

		if (!bookingIds.isEmpty()) {
			paymentRepository.deleteByBookingIds(bookingIds);
		}
		bookingRepository.deleteByUserId(userId);
		userRepository.deleteById(userId);
	}

	@Override
	public User updateUser(Long id, User updatedUser) {
		User existingUser = userRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("User not found with id " + id));

		existingUser.setName(updatedUser.getName());
		existingUser.setEmail(updatedUser.getEmail());
		existingUser.setPassword(updatedUser.getPassword());
		existingUser.setRole(updatedUser.getRole());

		return userRepository.save(existingUser);
	}

	@Override
	public User findById(Long id) {
	    return userRepository.findById(id)
	            .orElseThrow(() -> new NoSuchElementException("User not found with id: " + id));
	}
	
	@Override
	public User findByEmail(String email) {
	    return userRepository.findByEmail(email)
	        .orElseThrow(() -> new RuntimeException("User not found with email: " + email));
	}


}
