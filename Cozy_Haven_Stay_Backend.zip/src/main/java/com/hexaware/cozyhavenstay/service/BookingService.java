package com.hexaware.cozyhavenstay.service;

import com.hexaware.cozyhavenstay.entities.Booking;

import java.util.List;
import java.util.Optional;

public interface BookingService {

	Booking saveBooking(Booking booking);

	List<Booking> getAllBookings();

	Booking cancelBooking(Long id, String reason);

	Optional<Booking> getBookingByRoomIdAndIsCancelledFalse(Long roomId);

	Booking getBookingById(Long id);

	boolean deleteBooking(Long id);

	List<Booking> getBookingsByOwnerId(Long ownerId);

}
