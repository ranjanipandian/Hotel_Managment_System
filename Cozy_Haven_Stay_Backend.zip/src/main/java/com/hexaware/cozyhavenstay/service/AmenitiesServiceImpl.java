package com.hexaware.cozyhavenstay.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.cozyhavenstay.entities.Amenities;
import com.hexaware.cozyhavenstay.repository.AmenitiesRepository;

@Service
public class AmenitiesServiceImpl implements AmenitiesService {

	private final AmenitiesRepository amenitiesRepository;

	@Autowired
	public AmenitiesServiceImpl(AmenitiesRepository amenitiesRepository) {
		this.amenitiesRepository = amenitiesRepository;
	}

	@Override
	public Amenities saveAmenity(Amenities amenity) {
		return amenitiesRepository.save(amenity);
	}

	@Override
	public List<Amenities> getAllAmenities() {
		return amenitiesRepository.findAll();
	}

	@Override
	public Amenities updateAmenity(Long id, Amenities updatedAmenity) {
		Optional<Amenities> optional = amenitiesRepository.findById(id);
		if (optional.isPresent()) {
			Amenities existing = optional.get();
			existing.setName(updatedAmenity.getName());
			existing.setHotel(updatedAmenity.getHotel());
			existing.setDescription(updatedAmenity.getDescription());
			return amenitiesRepository.save(existing);
		}
		return null;
	}

	@Override
	public boolean deleteAmenity(Long id) {
		if (amenitiesRepository.existsById(id)) {
			amenitiesRepository.deleteById(id);
			return true;
		}
		return false;
	}

	@Override
	public List<Amenities> getAmenitiesByHotel(Long hotelId) {
		return amenitiesRepository.findByHotelId(hotelId);
	}

	@Override
	public List<Amenities> getAmenitiesByOwnerId(Long ownerId) {
		return amenitiesRepository.findByHotelOwnerId(ownerId);
	}
}
