package com.hexaware.cozyhavenstay.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.hexaware.cozyhavenstay.entities.Room;
import com.hexaware.cozyhavenstay.repository.RoomRepository;

@Service
public class RoomServiceImpl implements RoomService {

    @Autowired
    private RoomRepository roomRepository;

    @Override
    public Room saveRoom(Room room) {
        return roomRepository.save(room);
    }

    @Override
    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }

    @Override
    public List<Room> findByHotelId(Long hotelId) {
        return roomRepository.findByHotelId(hotelId);
    }

    @Override
    public List<Room> findByRoomType(String roomType) {
        return roomRepository.findByRoomType(roomType);
    }

    @Override
    public List<Room> findByPriceBetween(double minPrice, double maxPrice) {
        return roomRepository.findByPriceBetween(minPrice, maxPrice);
    }

    @Override
    public List<Room> findByIsAvailable(boolean isAvailable) {
        return roomRepository.findByIsAvailable(isAvailable);
    }

    @Override
    public void deleteRoom(Long id) {
        Room existingRoom = roomRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Room not found with id: " + id));
        roomRepository.delete(existingRoom);
    }

    @Override
    public Room updateRoom(Long id, Room roomDetails) {
        Room existingRoom = roomRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Room not found with id: " + id));

        existingRoom.setRoomType(roomDetails.getRoomType());
        existingRoom.setBedType(roomDetails.getBedType());
        existingRoom.setPrice(roomDetails.getPrice());
        existingRoom.setAccomodate(roomDetails.getAccomodate());
        existingRoom.setAc(roomDetails.isAc());
        existingRoom.setAvailable(roomDetails.isAvailable());
        existingRoom.setHotel(roomDetails.getHotel());

        return roomRepository.save(existingRoom);
    }

    @Override
    public Room getRoomById(Long id) {
        return roomRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Room not found with id: " + id));
    }
    
    @Override
    public Room findById(Long id) {
        return roomRepository.findById(id)
            .orElseThrow(() -> new NoSuchElementException("Room not found with id: " + id));
    }
    
    @Override
    public List<Room> findByHotelIdAndIsAvailable(Long hotelId, boolean isAvailable) {
        return roomRepository.findByHotelIdAndIsAvailable(hotelId, isAvailable);
    }
    
    @Override
    public List<Room> findRoomsByOwnerId(Long ownerId) {
        return roomRepository.findByHotelOwnerId(ownerId);
    }


}
