package com.hexaware.cozyhavenstay.service;

import java.util.List;
import java.util.Optional;

import com.hexaware.cozyhavenstay.entities.Payment;

public interface PaymentService {

	Payment savePayment(Payment payment);

	Optional<Payment> getPaymentById(Long id);

	Optional<Payment> getPaymentByTransactionId(String transactionId);

	List<Payment> getAllPayments();

	List<Payment> findByStatus(boolean status);

	void deletePayment(Long id);
	
	List<Payment> findByUserId(Long userId);

	List<Payment> findPaymentsByOwnerId(Long ownerId);
}
