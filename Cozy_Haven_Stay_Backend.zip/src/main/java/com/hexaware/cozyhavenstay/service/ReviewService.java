package com.hexaware.cozyhavenstay.service;

import java.util.List;

import com.hexaware.cozyhavenstay.entities.Review;

public interface ReviewService {
	Review saveReview(Review review);

	List<Review> getAllReviews();

	List<Review> getReviewsByHotel(Long hotelId);

	List<Review> getReviewsByUser(Long userId);

	Review updateReview(Long id, Review review);

	boolean deleteReview(Long id);
	
	List<Review> getReviewsByOwner(Long ownerId);

}
