package com.hexaware.cozyhavenstay.service;

import java.util.List;

import com.hexaware.cozyhavenstay.entities.Room;

public interface RoomService {
	Room saveRoom(Room room);

	List<Room> getAllRooms();

	List<Room> findByHotelId(Long hotelId);

	List<Room> findByRoomType(String roomType);

	List<Room> findByPriceBetween(double minPrice, double maxPrice);

	List<Room> findByIsAvailable(boolean isAvailable);

	List<Room> findRoomsByOwnerId(Long ownerId);

	void deleteRoom(Long id);

	Room updateRoom(Long id, Room room);

	Room getRoomById(Long id);

	Room findById(Long roomId);

	List<Room> findByHotelIdAndIsAvailable(Long hotelId, boolean isAvailable);
}
