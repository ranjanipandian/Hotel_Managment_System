package com.hexaware.cozyhavenstay.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.cozyhavenstay.dto.HotelDTO;
import com.hexaware.cozyhavenstay.entities.Hotel;
import com.hexaware.cozyhavenstay.entities.User;
import com.hexaware.cozyhavenstay.exception.ResourceNotFoundException;
import com.hexaware.cozyhavenstay.mapper.HotelMapper;
import com.hexaware.cozyhavenstay.repository.HotelRepository;
import com.hexaware.cozyhavenstay.repository.UserRepository;

@Service
public class HotelServiceImpl implements HotelService {

    @Autowired
    private HotelRepository hotelRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public Hotel saveHotel(HotelDTO hotelDTO) {
        Optional<Hotel> existingHotel = hotelRepository.findByNameAndLocationIgnoreCase(hotelDTO.getName(), hotelDTO.getLocation());
        if (existingHotel.isPresent()) {
            throw new RuntimeException("Hotel already exists with name '" + hotelDTO.getName() + "' and location '" + hotelDTO.getLocation() + "'");
        }

        User owner = userRepository.findById(hotelDTO.getOwnerId())
                .orElseThrow(() -> new ResourceNotFoundException("Owner not found with ID: " + hotelDTO.getOwnerId()));

        Hotel hotel = HotelMapper.fromDTO(hotelDTO, owner);
        return hotelRepository.save(hotel);
    }

    @Override
    public List<Hotel> getAllHotels() {
        return hotelRepository.findAll();
    }

    @Override
    public Optional<Hotel> findById(Long id) {
        return hotelRepository.findById(id);
    }

    @Override
    public List<Hotel> findByCityIgnoreCase(String city) {
        return hotelRepository.findByCityIgnoreCase(city);
    }

    @Override
    public void deleteHotel(Long id) {
        if (!hotelRepository.existsById(id)) {
            throw new ResourceNotFoundException("Hotel not found with ID: " + id);
        }
        hotelRepository.deleteById(id);
    }

    @Override
    public Hotel updateHotel(Long id, HotelDTO hotelDTO) {
        Hotel existingHotel = hotelRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Hotel not found with ID: " + id));

        User owner = userRepository.findById(hotelDTO.getOwnerId())
                .orElseThrow(() -> new ResourceNotFoundException("Owner not found with ID: " + hotelDTO.getOwnerId()));

        existingHotel.setName(hotelDTO.getName());
        existingHotel.setCity(hotelDTO.getCity());
        existingHotel.setLocation(hotelDTO.getLocation());
        existingHotel.setPhoneno(hotelDTO.getPhoneno());
        existingHotel.setOwner(owner);

        return hotelRepository.save(existingHotel);
    }

    @Override
    public List<Hotel> getHotelsByOwnerId(Long ownerId) {
        return hotelRepository.findByOwnerId(ownerId);
    }
}
