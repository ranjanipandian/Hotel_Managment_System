package com.hexaware.cozyhavenstay.service;

import java.util.List;
import org.springframework.stereotype.Service;

import com.hexaware.cozyhavenstay.entities.Review;
import com.hexaware.cozyhavenstay.repository.ReviewRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class ReviewServiceImpl implements ReviewService {

	private final ReviewRepository reviewRepository;

	public ReviewServiceImpl(ReviewRepository reviewRepository) {
		this.reviewRepository = reviewRepository;
	}

	@Override
	public Review saveReview(Review review) {
		return reviewRepository.save(review);
	}

	@Override
	public List<Review> getAllReviews() {
		return reviewRepository.findAll();
	}

	@Override
	public List<Review> getReviewsByHotel(Long hotelId) {
		return reviewRepository.findByHotelId(hotelId);
	}

	@Override
	public List<Review> getReviewsByUser(Long userId) {
		return reviewRepository.findByUserId(userId);
	}

	@Override
	public Review updateReview(Long id, Review updatedReview) {
		Review existingReview = reviewRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("Review not found with id " + id));
		existingReview.setRating(updatedReview.getRating());
		existingReview.setComment(updatedReview.getComment());
		
		return reviewRepository.save(existingReview);
	}

	@Override
	public boolean deleteReview(Long id) {
		if (!reviewRepository.existsById(id)) {
			throw new EntityNotFoundException("Review not found with id " + id);
		}
		reviewRepository.deleteById(id);
		return true;
	}
	
	@Override
	public List<Review> getReviewsByOwner(Long ownerId) {
	    return reviewRepository.findByOwnerId(ownerId);
	}


}
