package com.hexaware.cozyhavenstay.enums;

public enum Role {
    GUEST,
    OWNER,
    ADMIN
}