package com.hexaware.cozyhavenstay.controller;

import com.hexaware.cozyhavenstay.dto.JwtAuthResponse;
import com.hexaware.cozyhavenstay.dto.LoginDTO;
import com.hexaware.cozyhavenstay.dto.RegisterDTO;
import com.hexaware.cozyhavenstay.dto.UserDTO;
import com.hexaware.cozyhavenstay.entities.User;
import com.hexaware.cozyhavenstay.enums.Role;
import com.hexaware.cozyhavenstay.repository.UserRepository;
import com.hexaware.cozyhavenstay.security.JwtTokenUtil;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:5173")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/login")
    public ResponseEntity<JwtAuthResponse> authenticateUser(@RequestBody LoginDTO loginDto) {

    	Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(loginDto.getEmail(), loginDto.getPassword())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        String token = jwtTokenUtil.generateToken(authentication);

        User user = userRepository.findByEmail(loginDto.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found with email: " + loginDto.getEmail()));

        UserDTO userDto = new UserDTO();
        userDto.setId(user.getId());
        userDto.setUserName(user.getName());
        userDto.setEmail(user.getEmail());
        userDto.setRole(user.getRole().name());

        JwtAuthResponse response = new JwtAuthResponse(token, userDto);

        return ResponseEntity.ok(response);
    }



    @PostMapping("/register")
    public ResponseEntity<String> register(@Valid @RequestBody RegisterDTO registerDTO) {
        if (userRepository.findByEmail(registerDTO.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().body("Email is already in use");
        }

        User user = new User();
        user.setName(registerDTO.getName());
        user.setEmail(registerDTO.getEmail());
        user.setPassword(passwordEncoder.encode(registerDTO.getPassword()));

        user.setRole(Role.GUEST); 

        userRepository.save(user);
        return ResponseEntity.ok("User registered successfully");
    }

}
