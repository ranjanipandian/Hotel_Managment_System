package com.hexaware.cozyhavenstay.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.hexaware.cozyhavenstay.dto.BookingDTO;
import com.hexaware.cozyhavenstay.dto.CancelBookingDTO;
import com.hexaware.cozyhavenstay.entities.Booking;
import com.hexaware.cozyhavenstay.entities.Room;
import com.hexaware.cozyhavenstay.entities.User;
import com.hexaware.cozyhavenstay.mapper.BookingMapper;
import com.hexaware.cozyhavenstay.service.BookingService;
import com.hexaware.cozyhavenstay.service.RoomService;
import com.hexaware.cozyhavenstay.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "http://localhost:5173")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @Autowired
    private UserService userService;

    @Autowired
    private RoomService roomService;

    @PreAuthorize("hasRole('GUEST')")
    @PostMapping("/save")
    public ResponseEntity<BookingDTO> saveBooking(@Valid @RequestBody BookingDTO bookingDTO) {
        User user = userService.findById(bookingDTO.getUserId());
        Room room = roomService.findById(bookingDTO.getRoomId());
        Booking booking = BookingMapper.toEntity(bookingDTO, user, room);
        Booking savedBooking = bookingService.saveBooking(booking);
        BookingDTO savedDto = BookingMapper.toDTO(savedBooking);
        return ResponseEntity.ok(savedDto);
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
    @GetMapping
    public ResponseEntity<List<BookingDTO>> getAllBookings() {
        List<Booking> bookings = bookingService.getAllBookings();
        List<BookingDTO> bookingDTOs = bookings.stream()
            .map(BookingMapper::toDTO)
            .collect(Collectors.toList());
        return ResponseEntity.ok(bookingDTOs);
    }

    @PreAuthorize("hasAnyRole('GUEST', 'ADMIN', 'OWNER')")
    @PutMapping("/cancel/{id}")
    public ResponseEntity<BookingDTO> cancelBooking(@PathVariable Long id, @Valid @RequestBody CancelBookingDTO cancelDto) {
        Booking cancelledBooking = bookingService.cancelBooking(id, cancelDto.getReason());
        BookingDTO cancelledDTO = BookingMapper.toDTO(cancelledBooking);
        return ResponseEntity.ok(cancelledDTO);
    }

    @PreAuthorize("hasAnyRole('GUEST', 'ADMIN', 'OWNER')")
    @GetMapping("/{id}")
    public ResponseEntity<BookingDTO> getBookingById(@PathVariable Long id) {
        Booking booking = bookingService.getBookingById(id);
        BookingDTO dto = BookingMapper.toDTO(booking);
        return ResponseEntity.ok(dto);
    }
    
    @PreAuthorize("hasAnyRole('ADMIN', 'GUEST')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBooking(@PathVariable Long id) {
        boolean deleted = bookingService.deleteBooking(id); 
        if (!deleted) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build(); 
    }

    @PreAuthorize("hasRole('OWNER')")
    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<List<BookingDTO>> getBookingsByOwnerId(@PathVariable Long ownerId) {
        List<Booking> bookings = bookingService.getBookingsByOwnerId(ownerId);
        List<BookingDTO> bookingDTOs = bookings.stream()
                .map(BookingMapper::toDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(bookingDTOs);
    }

}
