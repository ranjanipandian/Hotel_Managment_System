package com.hexaware.cozyhavenstay.controller;

import com.hexaware.cozyhavenstay.entities.ContactMessage;
import com.hexaware.cozyhavenstay.repository.ContactMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/contact")
@CrossOrigin(origins = "http://localhost:5173")
public class ContactController {

    @Autowired
    private ContactMessageRepository contactRepo;

    @PostMapping("/send")
    public ResponseEntity<String> sendMessage(@RequestBody ContactMessage contactMessage) {
        contactRepo.save(contactMessage);
        return ResponseEntity.ok("Message received successfully.");
    }

    @GetMapping("/all")
    public ResponseEntity<?> getAllMessages() {
        return ResponseEntity.ok(contactRepo.findAll());
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteMessage(@PathVariable Long id) {
        contactRepo.deleteById(id);
        return ResponseEntity.ok().build();
    }

}

