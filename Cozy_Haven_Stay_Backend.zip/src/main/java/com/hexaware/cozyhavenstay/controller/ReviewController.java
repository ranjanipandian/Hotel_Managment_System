package com.hexaware.cozyhavenstay.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.hexaware.cozyhavenstay.dto.ReviewDTO;
import com.hexaware.cozyhavenstay.entities.Review;
import com.hexaware.cozyhavenstay.mapper.ReviewMapper;
import com.hexaware.cozyhavenstay.service.ReviewService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/reviews")
@CrossOrigin(origins = "http://localhost:5173")
public class ReviewController {

	@Autowired
	private ReviewService reviewService;

	@PreAuthorize("isAuthenticated()")
	@PostMapping("/save")
	public ResponseEntity<Review> saveReview(@Valid @RequestBody Review review) {
		return ResponseEntity.ok(reviewService.saveReview(review));
	}

	@PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
	@GetMapping
	public ResponseEntity<List<ReviewDTO>> getAllReviews() {
		List<Review> reviews = reviewService.getAllReviews();
		List<ReviewDTO> dtos = reviews.stream().map(ReviewMapper::toDTO).collect(Collectors.toList());
		return ResponseEntity.ok(dtos);
	}

	@PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
	@GetMapping("/hotel/{hotelId}")
	public ResponseEntity<List<ReviewDTO>> getReviewsByHotel(@PathVariable Long hotelId) {
		List<Review> reviews = reviewService.getReviewsByHotel(hotelId);
		List<ReviewDTO> dtos = reviews.stream().map(ReviewMapper::toDTO).collect(Collectors.toList());
		return ResponseEntity.ok(dtos);
	}

	@PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
	@GetMapping("/user/{userId}")
	public ResponseEntity<List<ReviewDTO>> getReviewsByUser(@PathVariable Long userId) {
		List<Review> reviews = reviewService.getReviewsByUser(userId);
		List<ReviewDTO> dtos = reviews.stream().map(ReviewMapper::toDTO).collect(Collectors.toList());
		return ResponseEntity.ok(dtos);
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('GUEST')")
	@PutMapping("/{id}")
	public ResponseEntity<?> updateReview(@PathVariable Long id, @Valid @RequestBody Review review) {
		Review updatedReview = reviewService.updateReview(id, review);
		if (updatedReview == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(updatedReview);
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('GUEST')")
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteReview(@PathVariable Long id) {
		boolean deleted = reviewService.deleteReview(id);
		if (!deleted) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.noContent().build();
	}
	
	@PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
	@GetMapping("/owner/{ownerId}")
	public ResponseEntity<List<ReviewDTO>> getReviewsByOwner(@PathVariable Long ownerId) {
	    List<Review> reviews = reviewService.getReviewsByOwner(ownerId);
	    List<ReviewDTO> dtos = reviews.stream().map(ReviewMapper::toDTO).collect(Collectors.toList());
	    return ResponseEntity.ok(dtos);
	}

}
