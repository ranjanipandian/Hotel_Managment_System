package com.hexaware.cozyhavenstay.controller;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.hexaware.cozyhavenstay.dto.UserDTO;
import com.hexaware.cozyhavenstay.entities.User;
import com.hexaware.cozyhavenstay.mapper.UserMapper;
import com.hexaware.cozyhavenstay.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:5173")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/save")
    public ResponseEntity<?> saveUser(@Valid @RequestBody User user) {
        try {
            User savedUser = userService.saveUser(user);
            return ResponseEntity.ok(savedUser);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error saving user: " + e.getMessage());
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'GUEST', 'OWNER')")
    @GetMapping("/{id}")
    public ResponseEntity<List<UserDTO>> getAllUsersByID() {
        List<User> users = userService.getAllUsers();
        List<UserDTO> userDTOs = users.stream()
                                      .map(UserMapper::toDTO)
                                      .toList();
        return ResponseEntity.ok(userDTOs);
    }

    
    @PreAuthorize("hasAnyRole('ADMIN', 'GUEST', 'OWNER')")
    @PutMapping("/update-profile")
    public ResponseEntity<?> updateUserProfile(Principal principal, @Valid @RequestBody UserDTO userDTO) {
        try {
            String email = principal.getName();
            User existingUser = userService.findByEmail(email);

            if (existingUser == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
            }

            existingUser.setName(userDTO.getUserName());
            existingUser.setPhoneNumber(userDTO.getPhoneNumber());
            existingUser.setEmail(userDTO.getEmail());

            
            if (userDTO.getRole() != null) {
                existingUser.setRole(UserMapper.toEntity(userDTO).getRole());
            }

            User updatedUser = userService.saveUser(existingUser);
            return ResponseEntity.ok(UserMapper.toDTO(updatedUser));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to update profile: " + e.getMessage());
        }
    }

    
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'GUEST', 'OWNER')")
    public ResponseEntity<?> updateUserById(@PathVariable Long id, @Valid @RequestBody UserDTO userDTO) {
        try {
            Optional<User> optionalUser = userService.getUserById(id);
            if (optionalUser.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
            }

            User existingUser = optionalUser.get();
            existingUser.setName(userDTO.getUserName());
            existingUser.setPhoneNumber(userDTO.getPhoneNumber());
            existingUser.setEmail(userDTO.getEmail());

            if (userDTO.getRole() != null) {
                existingUser.setRole(UserMapper.toEntity(userDTO).getRole());
            }

            User updatedUser = userService.saveUser(existingUser);
            return ResponseEntity.ok(UserMapper.toDTO(updatedUser));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to update user: " + e.getMessage());
        }
    }


    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        try {
            userService.deleteUser(id);
            return ResponseEntity.ok("Deleted Successfully!!");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to delete user: " + e.getMessage());
        }
    }

    @GetMapping("/me")
    @PreAuthorize("hasAnyRole('ADMIN', 'OWNER', 'GUEST')")
    public ResponseEntity<?> getCurrentUser(Principal principal) {
        try {
            String email = principal.getName();
            User user = userService.findByEmail(email);
            if (user == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
            }
            return ResponseEntity.ok(UserMapper.toDTO(user));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to get current user: " + e.getMessage());
        }
    }
}
