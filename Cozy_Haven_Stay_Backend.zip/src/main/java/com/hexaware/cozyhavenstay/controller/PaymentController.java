package com.hexaware.cozyhavenstay.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.hexaware.cozyhavenstay.dto.PaymentDTO;
import com.hexaware.cozyhavenstay.entities.Booking;
import com.hexaware.cozyhavenstay.entities.Payment;
import com.hexaware.cozyhavenstay.mapper.PaymentMapper;
import com.hexaware.cozyhavenstay.service.BookingService;
import com.hexaware.cozyhavenstay.service.PaymentService;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "http://localhost:5173")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private BookingService bookingService;

    @PreAuthorize("hasRole('GUEST')")
    @PostMapping("/save")
    public ResponseEntity<PaymentDTO> savePayment(@Valid @RequestBody PaymentDTO paymentDTO) {
        Booking booking = bookingService.getBookingById(paymentDTO.getBookingId());
        Payment payment = PaymentMapper.toEntity(paymentDTO, booking);
        Payment saved = paymentService.savePayment(payment);
        return ResponseEntity.ok(PaymentMapper.toDTO(saved));
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
    @GetMapping
    public ResponseEntity<List<PaymentDTO>> getAllPayments() {
        List<PaymentDTO> dtos = paymentService.getAllPayments()
                .stream().map(PaymentMapper::toDTO).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/{id}")
    public ResponseEntity<PaymentDTO> getPaymentById(@PathVariable Long id) {
        Optional<Payment> paymentOpt = paymentService.getPaymentById(id);
        return paymentOpt.map(payment -> ResponseEntity.ok(PaymentMapper.toDTO(payment)))
                         .orElse(ResponseEntity.notFound().build());
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/transaction/{transactionId}")
    public ResponseEntity<PaymentDTO> getPaymentByTransactionId(@PathVariable String transactionId) {
        Optional<Payment> paymentOpt = paymentService.getPaymentByTransactionId(transactionId);
        return paymentOpt.map(payment -> ResponseEntity.ok(PaymentMapper.toDTO(payment)))
                         .orElse(ResponseEntity.notFound().build());
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
    @GetMapping("/status/{status}")
    public ResponseEntity<List<PaymentDTO>> getPaymentsByStatus(@PathVariable boolean status) {
        List<PaymentDTO> dtos = paymentService.findByStatus(status)
                .stream().map(PaymentMapper::toDTO).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePayment(@PathVariable Long id) {
        try {
            paymentService.deletePayment(id);
            return ResponseEntity.ok("Deleted Successfully!!");
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
    @PreAuthorize("hasRole('OWNER')")
    @GetMapping("/owner/{ownerId}/earnings")
    public ResponseEntity<Map<String, Object>> getOwnerEarnings(@PathVariable Long ownerId) {
        List<Payment> payments = paymentService.findPaymentsByOwnerId(ownerId);

        double totalEarnings = payments.stream()
            .mapToDouble(p -> {
                Double amount = p.getTotalAmount();
                return amount != null ? amount : 0.0;
            })
            .sum();

        List<Map<String, Object>> report = payments.stream().map(payment -> {
            Map<String, Object> item = new HashMap<>();
            item.put("date", payment.getPaymentDate());
            item.put("amount", payment.getTotalAmount());

            String hotelName = "N/A";
            try {
                hotelName = payment.getBooking()
                                   .getRoom()
                                   .getHotel()
                                   .getName();
            } catch (Exception e) {
                hotelName = "Unknown Hotel";
            }

            item.put("hotelName", hotelName);
            return item;
        }).collect(Collectors.toList());

        Map<String, Object> response = new HashMap<>();
        response.put("totalEarnings", totalEarnings);
        response.put("detailedReport", report);

        return ResponseEntity.ok(response);
    }

}
