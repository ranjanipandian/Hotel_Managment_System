package com.hexaware.cozyhavenstay.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.hexaware.cozyhavenstay.dto.AmenitiesDTO;
import com.hexaware.cozyhavenstay.entities.Amenities;
import com.hexaware.cozyhavenstay.entities.Hotel;
import com.hexaware.cozyhavenstay.mapper.AmenitiesMapper;
import com.hexaware.cozyhavenstay.service.AmenitiesService;
import com.hexaware.cozyhavenstay.service.HotelService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/amenities")
@CrossOrigin(origins = "http://localhost:5173")
public class AmenitiesController {

    @Autowired
    private AmenitiesService amenitiesService;

    @Autowired
    private HotelService hotelService;

    @PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
    @PostMapping("/save")
    public ResponseEntity<AmenitiesDTO> saveAmenity(@Valid @RequestBody AmenitiesDTO amenitiesDTO) {
        Optional<Hotel> optionalHotel = hotelService.findById(amenitiesDTO.getHotelId());

        if (optionalHotel.isEmpty()) {
            return ResponseEntity.badRequest().body(null);
        }

        Amenities amenity = AmenitiesMapper.toEntity(amenitiesDTO, optionalHotel.get());
        Amenities saved = amenitiesService.saveAmenity(amenity);
        return ResponseEntity.ok(AmenitiesMapper.toDTO(saved));
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'OWNER', 'GUEST')")
    @GetMapping
    public ResponseEntity<List<AmenitiesDTO>> getAllAmenities() {
        List<Amenities> amenities = amenitiesService.getAllAmenities();
        List<AmenitiesDTO> dtos = amenities.stream()
            .map(AmenitiesMapper::toDTO)
            .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'OWNER', 'GUEST')")
    @GetMapping("/hotel/{hotelId}")
    public ResponseEntity<List<AmenitiesDTO>> getAmenitiesByHotel(@PathVariable Long hotelId) {
        List<Amenities> amenities = amenitiesService.getAmenitiesByHotel(hotelId);
        List<AmenitiesDTO> dtos = amenities.stream()
            .map(AmenitiesMapper::toDTO)
            .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
    @PutMapping("/{id}")
    public ResponseEntity<AmenitiesDTO> updateAmenity(@PathVariable Long id, @Valid @RequestBody AmenitiesDTO amenitiesDTO) {
        Optional<Hotel> optionalHotel = hotelService.findById(amenitiesDTO.getHotelId());
        if (optionalHotel.isEmpty()) return ResponseEntity.badRequest().build();

        Amenities updated = amenitiesService.updateAmenity(id, AmenitiesMapper.toEntity(amenitiesDTO, optionalHotel.get()));
        if (updated == null) return ResponseEntity.notFound().build();

        return ResponseEntity.ok(AmenitiesMapper.toDTO(updated));
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'OWNER')")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAmenity(@PathVariable Long id) {
        boolean deleted = amenitiesService.deleteAmenity(id);
        return deleted ? ResponseEntity.ok("Deleted Successfully!") : ResponseEntity.notFound().build();
    }

    @PreAuthorize("hasRole('OWNER')")
    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<List<AmenitiesDTO>> getAmenitiesByOwner(@PathVariable Long ownerId) {
        List<Amenities> amenities = amenitiesService.getAmenitiesByOwnerId(ownerId);
        List<AmenitiesDTO> dtos = amenities.stream()
            .map(AmenitiesMapper::toDTO)
            .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }
}
