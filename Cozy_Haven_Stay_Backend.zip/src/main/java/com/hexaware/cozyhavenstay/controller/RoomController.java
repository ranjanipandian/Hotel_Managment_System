package com.hexaware.cozyhavenstay.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.hexaware.cozyhavenstay.dto.RoomDTO;
import com.hexaware.cozyhavenstay.entities.Booking;
import com.hexaware.cozyhavenstay.entities.Hotel;
import com.hexaware.cozyhavenstay.entities.Room;
import com.hexaware.cozyhavenstay.mapper.RoomMapper;
import com.hexaware.cozyhavenstay.service.BookingService;
import com.hexaware.cozyhavenstay.service.HotelService;
import com.hexaware.cozyhavenstay.service.RoomService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/rooms")
@CrossOrigin(origins = "http://localhost:5173")
public class RoomController {

    @Autowired
    private RoomService roomService;

    @Autowired
    private HotelService hotelService;

    @Autowired
    private BookingService bookingService;

    @PreAuthorize("hasAnyRole('ADMIN','OWNER')")
    @PostMapping("/save")
    public ResponseEntity<?> saveRoom(@Valid @RequestBody RoomDTO roomDTO) {
        Optional<Hotel> hotelOpt = hotelService.findById(roomDTO.getHotelId());
        if (hotelOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Invalid hotel ID");
        }
        Room room = RoomMapper.toEntity(roomDTO, hotelOpt.get());
        Room savedRoom = roomService.saveRoom(room);
        return ResponseEntity.ok(RoomMapper.toDTO(savedRoom));
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/hotel/{hotelId}")
    public ResponseEntity<List<RoomDTO>> getRoomsByHotelId(@PathVariable Long hotelId) {
        List<Room> rooms = roomService.findByHotelIdAndIsAvailable(hotelId, true);
        List<RoomDTO> dtos = rooms.stream()
                                  .map(RoomMapper::toDTO)
                                  .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping
    public ResponseEntity<List<RoomDTO>> getAllAvailableRooms() {
        List<Room> rooms = roomService.findByIsAvailable(true);
        List<RoomDTO> dtos = rooms.stream()
                                  .map(RoomMapper::toDTO)
                                  .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @PreAuthorize("hasAnyRole('ADMIN','OWNER')")
    @PatchMapping("/{id}/status")
    public ResponseEntity<?> updateRoomStatus(@PathVariable Long id, @RequestParam boolean isAvailable) {
        Room room = roomService.getRoomById(id);
        if (room == null) {
            return ResponseEntity.badRequest().body("Room not found with ID: " + id);
        }
        room.setAvailable(isAvailable);
        Room updatedRoom = roomService.saveRoom(room);
        return ResponseEntity.ok(RoomMapper.toDTO(updatedRoom));
    }

    @PreAuthorize("hasAnyRole('ADMIN','OWNER')")
    @PutMapping("/{id}")
    public ResponseEntity<?> updateRoom(@PathVariable Long id, @Valid @RequestBody RoomDTO roomDTO) {
        Optional<Hotel> hotelOpt = hotelService.findById(roomDTO.getHotelId());
        if (hotelOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Invalid hotel ID");
        }
        Room room = RoomMapper.toEntity(roomDTO, hotelOpt.get());
        room.setId(id);
        Room updatedRoom = roomService.updateRoom(id, room);
        return ResponseEntity.ok(RoomMapper.toDTO(updatedRoom));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteRoom(@PathVariable Long id) {
        roomService.deleteRoom(id);
        return ResponseEntity.ok("Deleted Successfully");
    }

    @GetMapping("/by-room-type/{roomType}")
    public ResponseEntity<List<Room>> getRoomsByRoomType(@PathVariable String roomType) {
        List<Room> rooms = roomService.findByRoomType(roomType);
        return ResponseEntity.ok(rooms);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/{id}")
    public ResponseEntity<RoomDTO> getRoomById(@PathVariable Long id) {
        Room room = roomService.getRoomById(id);
        if (room == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(RoomMapper.toDTO(room));
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/{roomId}/availability")
    public ResponseEntity<String> checkRoomAvailability(@PathVariable Long roomId) {
        Optional<Booking> booking = bookingService.getBookingByRoomIdAndIsCancelledFalse(roomId);
        if (booking.isPresent()) {
            return ResponseEntity.ok("Room is already booked");
        } else {
            return ResponseEntity.ok("Room is available");
        }
    }

    @PreAuthorize("hasRole('OWNER')")
    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<List<RoomDTO>> getRoomsByOwner(@PathVariable Long ownerId) {
        List<Room> rooms = roomService.findRoomsByOwnerId(ownerId);
        List<RoomDTO> dtos = rooms.stream()
                                  .map(RoomMapper::toDTO)
                                  .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }
    
    @PreAuthorize("hasRole('OWNER')")
    @PostMapping("/owner/{ownerId}/save")
    public ResponseEntity<?> addRoomByOwner(@PathVariable Long ownerId, @Valid @RequestBody RoomDTO roomDTO) {
        // Fetch all hotels owned by this owner
        List<Hotel> ownerHotels = hotelService.getHotelsByOwnerId(ownerId);

        boolean isHotelOwned = ownerHotels.stream()
            .anyMatch(hotel -> hotel.getId().equals(roomDTO.getHotelId()));

        if (!isHotelOwned) {
            return ResponseEntity.badRequest().body("Hotel does not belong to the owner.");
        }

        Optional<Hotel> hotelOpt = hotelService.findById(roomDTO.getHotelId());
        if (hotelOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Invalid hotel ID");
        }

        Room room = RoomMapper.toEntity(roomDTO, hotelOpt.get());
        Room savedRoom = roomService.saveRoom(room);
        return ResponseEntity.ok(RoomMapper.toDTO(savedRoom));
    }


}
