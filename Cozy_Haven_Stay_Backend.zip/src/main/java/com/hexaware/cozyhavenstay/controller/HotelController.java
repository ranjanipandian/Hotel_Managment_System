package com.hexaware.cozyhavenstay.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.hexaware.cozyhavenstay.dto.HotelDTO;
import com.hexaware.cozyhavenstay.dto.RoomDTO;
import com.hexaware.cozyhavenstay.entities.Hotel;
import com.hexaware.cozyhavenstay.entities.Room;
import com.hexaware.cozyhavenstay.mapper.HotelMapper;
import com.hexaware.cozyhavenstay.mapper.RoomMapper;
import com.hexaware.cozyhavenstay.service.HotelService;
import com.hexaware.cozyhavenstay.service.RoomService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/hotels")
@CrossOrigin(origins = "http://localhost:5173")
public class HotelController {

    @Autowired
    private HotelService hotelService;
    
    @Autowired
    private RoomService roomService;

    @PreAuthorize("hasRole('ADMIN') or hasRole('OWNER')")
    @PostMapping("/save")
    public ResponseEntity<?> saveHotel(@Valid @RequestBody HotelDTO hotelDTO) {
        try {
            Hotel savedHotel = hotelService.saveHotel(hotelDTO);
            return ResponseEntity.ok(HotelMapper.toDTO(savedHotel));
        } catch (RuntimeException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping
    public ResponseEntity<List<HotelDTO>> getAllHotels() {
        List<Hotel> hotels = hotelService.getAllHotels();
        List<HotelDTO> dtos = hotels.stream()
                                    .map(HotelMapper::toDTO)
                                    .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @PreAuthorize("hasRole('ADMIN') or hasRole('OWNER') or hasRole('GUEST')")
    @GetMapping("/{id}")
    public ResponseEntity<?> getHotelById(@PathVariable Long id) {
        return hotelService.findById(id)
            .map(hotel -> ResponseEntity.ok(HotelMapper.toDTO(hotel)))
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PreAuthorize("hasRole('ADMIN') or hasRole('OWNER')")
    @PutMapping("/{id}")
    public ResponseEntity<?> updateHotel(@PathVariable Long id, @Valid @RequestBody HotelDTO hotelDTO) {
        try {
            Hotel updatedHotel = hotelService.updateHotel(id, hotelDTO);
            return ResponseEntity.ok(HotelMapper.toDTO(updatedHotel));
        } catch (RuntimeException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @PreAuthorize("hasRole('ADMIN') or hasRole('OWNER')")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteHotel(@PathVariable Long id) {
        hotelService.deleteHotel(id);
        return ResponseEntity.ok("Deleted Successfully");
    }
    
    @GetMapping("/{hotelId}/rooms")
    public ResponseEntity<List<RoomDTO>> getRoomsByHotelId(@PathVariable Long hotelId) {
        List<Room> rooms = roomService.findByHotelId(hotelId);
        List<RoomDTO> dtos = rooms.stream()
                                  .map(RoomMapper::toDTO)
                                  .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }
    
    @PreAuthorize("hasRole('GUEST') or hasRole('OWNER') or hasRole('ADMIN')")
    @GetMapping("/city/{city}")
    public ResponseEntity<List<HotelDTO>> getHotelsByCity(@PathVariable("city") String city) {
        List<Hotel> hotels = hotelService.findByCityIgnoreCase(city);
        List<HotelDTO> dtos = hotels.stream()
                                    .map(HotelMapper::toDTO)
                                    .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }
    
    @PreAuthorize("hasRole('OWNER')")
    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<List<HotelDTO>> getHotelsByOwner(@PathVariable Long ownerId) {
        List<Hotel> hotels = hotelService.getHotelsByOwnerId(ownerId);
        List<HotelDTO> dtos = hotels.stream()
                                    .map(HotelMapper::toDTO)
                                    .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

}
