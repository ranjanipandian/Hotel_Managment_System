package com.hexaware.cozyhavenstay.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;
@Configuration
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    @Autowired
    private JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;

    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .cors().and()
            .csrf(csrf -> csrf.disable())
            .exceptionHandling(exception -> exception.authenticationEntryPoint(jwtAuthenticationEntryPoint))
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/auth/**").permitAll()

                // USERS
                .requestMatchers("/api/users/me").hasAnyRole("ADMIN", "OWNER", "GUEST")
                .requestMatchers("/api/users/{id}").hasAnyRole("ADMIN", "OWNER", "GUEST")
                .requestMatchers("/api/users/update-profile").hasAnyRole("ADMIN", "OWNER", "GUEST")
                .requestMatchers("/api/users/save").hasAnyRole("ADMIN")
                .requestMatchers("/api/users").hasAnyRole("ADMIN")
                
                // HOTELS
                .requestMatchers("/api/hotels/**").hasAnyRole("ADMIN", "OWNER", "GUEST")


                // ROOMS
                .requestMatchers(HttpMethod.GET, "/api/rooms/**").hasAnyRole("ADMIN", "OWNER", "GUEST")
                .requestMatchers(HttpMethod.PATCH, "/api/rooms/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.POST, "/api/rooms/**").hasAnyRole("ADMIN", "OWNER")
                .requestMatchers(HttpMethod.PUT, "/api/rooms/**").hasAnyRole("ADMIN", "OWNER")
                .requestMatchers(HttpMethod.DELETE, "/api/rooms/**").hasRole("ADMIN")
                
                
                // PAYMENTS
                .requestMatchers("/api/payments/save").hasRole("GUEST")
                .requestMatchers("/api/payments/**").hasAnyRole("OWNER", "ADMIN","GUEST")

                // REVIEWS
                .requestMatchers("/api/reviews/{id}").hasAnyRole("ADMIN", "GUEST")
                .requestMatchers("/api/reviews/hotel/{hotelId}").hasAnyRole("ADMIN", "OWNER")
                .requestMatchers("/api/reviews/user/{userId}").hasAnyRole("ADMIN", "OWNER")
                .requestMatchers("/api/reviews/save").hasRole("GUEST")
                .requestMatchers("/api/reviews").hasAnyRole("ADMIN", "OWNER")

                // BOOKINGS
                .requestMatchers("/api/bookings/cancel/{id}").hasAnyRole("ADMIN", "OWNER")
                .requestMatchers("/api/bookings/save").hasRole("GUEST")
                .requestMatchers("/api/bookings/**").hasAnyRole("ADMIN", "OWNER","GUEST")

                // AMENITIES
                .requestMatchers("/api/amenities/save").hasAnyRole("ADMIN", "OWNER")
                .requestMatchers("/api/amenities").hasAnyRole("ADMIN", "OWNER", "GUEST")
                .requestMatchers("/api/amenities/hotel/{hotelId}").hasAnyRole("ADMIN", "OWNER", "GUEST")
                .requestMatchers("/api/amenities/{id}").hasAnyRole("ADMIN", "OWNER")

                // IMAGES
                .requestMatchers("/api/images/**").hasAnyRole("ADMIN", "OWNER")

                //CONTACT
                .requestMatchers("/api/contact/**").permitAll()                
                .anyRequest().authenticated()
            )
            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of("http://localhost:5173")); 
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "PATCH","OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true); 

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
