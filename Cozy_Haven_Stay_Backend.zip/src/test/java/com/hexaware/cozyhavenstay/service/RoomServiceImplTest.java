package com.hexaware.cozyhavenstay.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.hexaware.cozyhavenstay.entities.Hotel;
import com.hexaware.cozyhavenstay.entities.Room;
import com.hexaware.cozyhavenstay.repository.RoomRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

public class RoomServiceImplTest {

    @Mock
    private RoomRepository roomRepository;

    @InjectMocks
    private RoomServiceImpl roomService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

   
    @Test
    public void testFindByHotelIdAndIsAvailable() {
        Room room1 = new Room();
        Room room2 = new Room();
        when(roomRepository.findByHotelIdAndIsAvailable(1L, true)).thenReturn(Arrays.asList(room1, room2));

        List<Room> rooms = roomService.findByHotelIdAndIsAvailable(1L, true);
        assertEquals(2, rooms.size());
    }

   
    @Test
    public void testUpdateRoom_Success() {
        Room existing = new Room();
        existing.setId(1L);
        existing.setRoomType("Deluxe");

        Room updated = new Room();
        updated.setRoomType("Super Deluxe");
        updated.setBedType("King");
        updated.setPrice(5000);
        updated.setAccomodate(2);
        updated.setAc(true);
        updated.setAvailable(true);
        updated.setHotel(new Hotel());

        when(roomRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(roomRepository.save(any(Room.class))).thenReturn(updated);

        Room result = roomService.updateRoom(1L, updated);
        assertEquals("Super Deluxe", result.getRoomType());
    }
}
