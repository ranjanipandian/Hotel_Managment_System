package com.hexaware.cozyhavenstay.service;

import com.hexaware.cozyhavenstay.entities.Hotel;
import com.hexaware.cozyhavenstay.repository.HotelRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class HotelServiceImplTest {

    @Mock
    private HotelRepository hotelRepository;

    @InjectMocks
    private HotelServiceImpl hotelService;

    @Test
    public void testFindById_HotelExists() {
        Hotel hotel = new Hotel();
        hotel.setId(1L);
        hotel.setName("Taj");

        when(hotelRepository.findById(1L)).thenReturn(Optional.of(hotel));

        Optional<Hotel> result = hotelService.findById(1L);

        assertTrue(result.isPresent());
        assertEquals("Taj", result.get().getName());

        verify(hotelRepository, times(1)).findById(1L);
    }

    @Test
    public void testFindById_HotelNotFound() {
        when(hotelRepository.findById(2L)).thenReturn(Optional.empty());

        Optional<Hotel> result = hotelService.findById(2L);

        assertFalse(result.isPresent());

        verify(hotelRepository, times(1)).findById(2L);

    }
}
