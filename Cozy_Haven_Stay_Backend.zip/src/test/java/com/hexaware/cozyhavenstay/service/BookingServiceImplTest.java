package com.hexaware.cozyhavenstay.service;

import com.hexaware.cozyhavenstay.entities.Booking;
import com.hexaware.cozyhavenstay.entities.Room;
import com.hexaware.cozyhavenstay.entities.User;
import com.hexaware.cozyhavenstay.exception.ResourceNotFoundException;
import com.hexaware.cozyhavenstay.repository.BookingRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BookingServiceImplTest {

    @Mock
    private BookingRepository bookingRepository;

    @InjectMocks
    private BookingServiceImpl bookingService;

    private Booking booking;
    private User user;
    private Room room;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        user = new User();
        user.setId(1L);

        room = new Room();
        room.setId(2L);

        booking = new Booking();
        booking.setId(100L);
        booking.setUser(user);
        booking.setRoom(room);
        booking.setCheckInDate(LocalDate.of(2025, 7, 1));
        booking.setCheckoutDate(LocalDate.of(2025, 7, 5));
        booking.setCancelled(false);
    }

    @Test
    void testSaveBooking_WhenNoOverlap_ShouldSaveSuccessfully() {
        when(bookingRepository.findOverlappingBookingsForUser(anyLong(), anyLong(), any(), any()))
                .thenReturn(Collections.emptyList());
        when(bookingRepository.save(any(Booking.class))).thenReturn(booking);

        Booking saved = bookingService.saveBooking(booking);

        assertNotNull(saved);
        assertEquals(booking.getId(), saved.getId());
        verify(bookingRepository, times(1)).save(booking);
    }

    @Test
    void testSaveBooking_WhenOverlapExists_ShouldThrowException() {
        when(bookingRepository.findOverlappingBookingsForUser(anyLong(), anyLong(), any(), any()))
                .thenReturn(List.of(booking));

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> {
            bookingService.saveBooking(booking);
        });

        assertEquals("You have already booked this room for the selected dates.", ex.getMessage());
        verify(bookingRepository, never()).save(any());
    }

    @Test
    void testGetAllBookings_ShouldReturnList() {
        when(bookingRepository.findAll()).thenReturn(List.of(booking));

        List<Booking> bookings = bookingService.getAllBookings();

        assertEquals(1, bookings.size());
        verify(bookingRepository, times(1)).findAll();
    }

    @Test
    void testCancelBooking_WhenBookingExistsAndNotCancelled_ShouldUpdateBooking() {
        when(bookingRepository.findById(100L)).thenReturn(Optional.of(booking));
        when(bookingRepository.save(any(Booking.class))).thenReturn(booking);

        Booking cancelled = bookingService.cancelBooking(100L, "Change of plans");

        assertTrue(cancelled.isCancelled());
        assertEquals("Change of plans", cancelled.getCancellationReason());
        assertNotNull(cancelled.getCancellationDate());
    }

    @Test
    void testCancelBooking_WhenAlreadyCancelled_ShouldThrowException() {
        booking.setCancelled(true);
        when(bookingRepository.findById(100L)).thenReturn(Optional.of(booking));

        IllegalStateException ex = assertThrows(IllegalStateException.class, () -> {
            bookingService.cancelBooking(100L, "Duplicate");
        });

        assertEquals("Booking is already cancelled.", ex.getMessage());
        verify(bookingRepository, never()).save(any());
    }

    @Test
    void testCancelBooking_WhenNotFound_ShouldThrowException() {
        when(bookingRepository.findById(100L)).thenReturn(Optional.empty());

        ResourceNotFoundException ex = assertThrows(ResourceNotFoundException.class, () -> {
            bookingService.cancelBooking(100L, "Invalid");
        });

        assertEquals("Booking not found with id: 100", ex.getMessage());
    }

    @Test
    void testGetBookingByRoomIdAndIsCancelledFalse() {
        when(bookingRepository.findByRoomIdAndIsCancelledFalse(2L)).thenReturn(Optional.of(booking));

        Optional<Booking> result = bookingService.getBookingByRoomIdAndIsCancelledFalse(2L);

        assertTrue(result.isPresent());
        assertEquals(booking.getId(), result.get().getId());
    }

    @Test
    void testGetBookingById_WhenFound_ShouldReturnBooking() {
        when(bookingRepository.findByIdWithRoomAndHotel(100L)).thenReturn(Optional.of(booking));

        Booking result = bookingService.getBookingById(100L);

        assertNotNull(result);
        assertEquals(100L, result.getId());
    }

    @Test
    void testGetBookingById_WhenNotFound_ShouldThrowException() {
        when(bookingRepository.findByIdWithRoomAndHotel(100L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> bookingService.getBookingById(100L));
    }

    @Test
    void testDeleteBooking_WhenExists_ShouldReturnTrue() {
        when(bookingRepository.existsById(100L)).thenReturn(true);

        boolean result = bookingService.deleteBooking(100L);

        assertTrue(result);
        verify(bookingRepository).deleteById(100L);
    }

    @Test
    void testDeleteBooking_WhenNotExists_ShouldReturnFalse() {
        when(bookingRepository.existsById(100L)).thenReturn(false);

        boolean result = bookingService.deleteBooking(100L);

        assertFalse(result);
        verify(bookingRepository, never()).deleteById(anyLong());
    }

    @Test
    void testGetBookingsByOwnerId_ShouldReturnList() {
        when(bookingRepository.findByRoom_Hotel_OwnerId(5L)).thenReturn(List.of(booking));

        List<Booking> result = bookingService.getBookingsByOwnerId(5L);

        assertEquals(1, result.size());
    }
}
