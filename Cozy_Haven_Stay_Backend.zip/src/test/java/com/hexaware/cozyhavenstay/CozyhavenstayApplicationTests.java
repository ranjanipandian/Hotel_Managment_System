package com.hexaware.cozyhavenstay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CozyhavenstayApplicationTests {

	@Test
	void contextLoads() {
	}

}
