import axios from 'axios';

const BASE_URL = 'http://localhost:8000/api/amenities';

export const getAmenitiesByHotelId = async (hotelId, token) => {
  const response = await axios.get(`${BASE_URL}/hotel/${hotelId}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return response.data;
};
