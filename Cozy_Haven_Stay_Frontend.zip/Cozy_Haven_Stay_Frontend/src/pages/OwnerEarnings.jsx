import React, { useEffect, useState } from 'react';
import axios from 'axios';

const OwnerEarnings = () => {
  const [earnings, setEarnings] = useState(0);
  const [report, setReport] = useState([]);
  const ownerId = localStorage.getItem('ownerId');
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchEarnings = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8000/api/payments/owner/${ownerId}/earnings`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setEarnings(response.data.totalEarnings);
        setReport(response.data.detailedReport || []);
      } catch (error) {
        console.error('Failed to fetch earnings:', error);
      }
    };

    if (ownerId && token) {
      fetchEarnings();
    }
  }, [ownerId, token]);

  return (
    <div className="container mt-5" style={{ fontFamily: 'Segoe UI, sans-serif' }}>
      <div className="text-center mb-4">
        <h2 className="fw-bold" style={{ color: '#0d6efd' }}>💰 Your Total Earnings</h2>
        <h3 className="text-success fw-bold">₹ {earnings.toFixed(2)}</h3>
      </div>

      {report.length > 0 ? (
        <div className="card shadow-sm p-4 rounded-4">
          <h5 className="mb-3 fw-semibold">📊 Detailed Earnings Report</h5>
          <div className="table-responsive">
            <table className="table table-bordered table-hover align-middle text-center">
              <thead className="table-light">
                <tr>
                  <th>Date</th>
                  <th>Hotel</th>
                  <th>Amount Earned</th>
                </tr>
              </thead>
              <tbody>
                {report.map((item, index) => (
                  <tr key={index}>
                    <td>{item.date}</td>
                    <td>{item.hotelName}</td>
                    <td className="text-success fw-semibold">₹ {item.amount?.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <p className="text-center text-muted">No earnings to show.</p>
      )}
    </div>
  );
};

export default OwnerEarnings;
