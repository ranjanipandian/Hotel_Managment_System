import React, { useState } from 'react';
import axios from 'axios';

const OwnerManageImages = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const token = localStorage.getItem('token');

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setSelectedFile(file);
    if (file) {
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      alert('Please select an image.');
      return;
    }

    const formData = new FormData();
    formData.append('file', selectedFile); 

    try {
      await axios.post('http://localhost:8000/api/images/upload', formData, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      alert('✅ Image uploaded successfully!');
      setSelectedFile(null);
      setPreviewUrl(null);
    } catch (error) {
      console.error('❌ Error uploading image:', error);
      alert('❌ Upload failed!');
    }
  };

  return (
    <div className="container mt-5" style={{ fontFamily: 'Segoe UI, sans-serif' }}>
      <div className="card shadow-sm p-4 rounded-4">
        <h2 className="text-center fw-bold mb-4" style={{ color: '#0d6efd' }}>
          📤 Upload Hotel or Room Image
        </h2>

        <div className="mb-3">
          <label className="form-label">Choose Image</label>
          <input type="file" className="form-control" onChange={handleFileChange} />
        </div>

        {previewUrl && (
          <div className="text-center mb-4">
            <img
              src={previewUrl}
              alt="Preview"
              className="img-thumbnail shadow-sm"
              style={{ maxHeight: '250px', objectFit: 'contain' }}
            />
          </div>
        )}

        <div className="text-center">
          <button className="btn btn-success px-4" onClick={handleUpload}>
            Upload
          </button>
        </div>
      </div>
    </div>
  );
};

export default OwnerManageImages;
