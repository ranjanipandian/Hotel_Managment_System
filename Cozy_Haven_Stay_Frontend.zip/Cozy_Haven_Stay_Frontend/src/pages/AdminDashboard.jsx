import React from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './AdminDashboard.css'; 

const AdminDashboard = () => {
  return (
    <div className="container mt-5">
      <h2 className="dashboard-heading">Welcome to Admin Dashboard</h2>
      <p className="dashboard-subheading">
        You can manage users, hotels, rooms, bookings, payments, and reviews here.
      </p>

      <div className="row row-cols-1 row-cols-md-3 g-4">
        <div className="col">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">User Management</h5>
              <p className="card-text">View, approve, or block platform users.</p>
              <Link to="/admin/users" className="btn btn-teal dashboard-btn">Manage Users</Link>
            </div>
          </div>
        </div>
        <div className="col">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">Hotel Management</h5>
              <p className="card-text">Approve, edit, or remove hotel listings.</p>
              <Link to="/admin/hotels" className="btn btn-teal dashboard-btn">Manage Hotels</Link>
            </div>
          </div>
        </div>
        <div className="col">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">Room Management</h5>
              <p className="card-text">Oversee room listings per hotel.</p>
              <Link to="/admin/rooms" className="btn btn-teal dashboard-btn">Manage Rooms</Link>
            </div>
          </div>
        </div>

        <div className="col">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">Booking Management</h5>
              <p className="card-text">View or cancel user bookings.</p>
              <Link to="/admin/bookings" className="btn btn-teal dashboard-btn">View Bookings</Link>
            </div>
          </div>
        </div>
        <div className="col">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">Review Moderation</h5>
              <p className="card-text">Delete inappropriate or spam reviews.</p>
              <Link to="/admin/reviews" className="btn btn-teal dashboard-btn">Moderate Reviews</Link>
            </div>
          </div>
        </div>
        <div className="col">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">Payments & Refunds</h5>
              <p className="card-text">Track and verify transactions.</p>
              <Link to="/admin/payments" className="btn btn-teal dashboard-btn">Manage Payments</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="row justify-content-center mt-4 g-4">
        
        <div className="col-md-4">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">Contact Messages</h5>
              <p className="card-text">View messages submitted via Contact Us form.</p>
              <Link to="/admin/contact-messages" className="btn btn-teal dashboard-btn">View Messages</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
