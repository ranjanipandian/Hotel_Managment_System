import React from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './AdminDashboard.css';

const OwnerDashboard = () => {
  return (
    <div className="container mt-5">
      <h2 className="dashboard-heading">Welcome to Owner Dashboard</h2>
      <p className="dashboard-subheading">
        You can manage your hotels, rooms, bookings, reviews, earnings, and images here.
      </p>

      <div className="row row-cols-1 row-cols-md-3 g-4">
        <div className="col">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">Hotel Management</h5>
              <p className="card-text">Add or edit your hotel listings.</p>
              <Link to="/owner/my-hotels" className="btn btn-teal dashboard-btn">Manage Hotels</Link>
            </div>
          </div>
        </div>

        <div className="col">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">Room Management</h5>
              <p className="card-text">Add new rooms or update existing ones.</p>
              <Link to="/owner/manage-rooms" className="btn btn-teal dashboard-btn">Manage Rooms</Link>
            </div>
          </div>
        </div>

        <div className="col">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">Booking Overview</h5>
              <p className="card-text">View and manage all guest bookings.</p>
              <Link to="/owner/bookings" className="btn btn-teal dashboard-btn">View Bookings</Link>
            </div>
          </div>
        </div>

        <div className="col">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">Earnings & Reports</h5>
              <p className="card-text">Track your earnings and download reports.</p>
              <Link to="/owner/earnings" className="btn btn-teal dashboard-btn">View Earnings</Link>
            </div>
          </div>
        </div>

        <div className="col">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">Guest Reviews</h5>
              <p className="card-text">See what guests are saying about your hotels.</p>
              <Link to="/owner/reviews" className="btn btn-teal dashboard-btn">View Reviews</Link>
            </div>
          </div>
        </div>

        <div className="col">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">Amenities</h5>
              <p className="card-text">Add or update room amenities.</p>
              <Link to="/owner/amenities" className="btn btn-teal dashboard-btn">Manage Amenities</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="row justify-content-center mt-4 g-4">
        <div className="col-md-4">
          <div className="card dashboard-card h-100 text-center">
            <div className="card-body">
              <h5 className="card-title">Image Gallery</h5>
              <p className="card-text">Upload and manage room or hotel images.</p>
              <Link to="/owner/image-gallery" className="btn btn-teal dashboard-btn">Manage Images</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OwnerDashboard;
