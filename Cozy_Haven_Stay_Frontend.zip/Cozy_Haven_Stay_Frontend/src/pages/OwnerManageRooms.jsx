import React, { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import { FaEdit, FaTrash, FaSave, FaTimes, FaPlus } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-toastify/dist/ReactToastify.css';

const OwnerManageRooms = () => {
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingRoom, setEditingRoom] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [newRoom, setNewRoom] = useState({
    roomType: '',
    bedType: '',
    price: '',
    accomodate: 1,
    isAc: false,
    isAvailable: true,
    hotelId: ''
  });

  const ownerId = localStorage.getItem('ownerId');
  const token = localStorage.getItem('token');

  const fetchOwnerRooms = useCallback(async () => {
    try {
      const response = await axios.get(`http://localhost:8000/api/rooms/owner/${ownerId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setRooms(response.data || []);
    } catch (error) {
      console.error('❌ Error fetching rooms:', error);
      toast.error('Failed to load rooms');
      setRooms([]);
    } finally {
      setLoading(false);
    }
  }, [ownerId, token]);

  useEffect(() => {
    fetchOwnerRooms();
  }, [fetchOwnerRooms]);

  const handleEditClick = (room) => {
    setEditingRoom({
      ...room,
      hotelId: room.hotel?.id || room.hotelId || null,
    });
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    const updateFn = editingRoom ? setEditingRoom : setNewRoom;

    updateFn((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSaveClick = async () => {
    try {
      const payload = {
        ...editingRoom,
        hotelId: editingRoom.hotelId
      };

      await axios.put(`http://localhost:8000/api/rooms/${editingRoom.id}`, payload, {
        headers: { Authorization: `Bearer ${token}` },
      });

      toast.success('Room updated successfully');
      setEditingRoom(null);
      fetchOwnerRooms();
    } catch (error) {
      console.error('❌ Error updating room:', error);
      toast.error('Failed to update room');
    }
  };

  const handleCancelClick = () => {
    setEditingRoom(null);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this room?')) return;
    try {
      await axios.delete(`http://localhost:8000/api/rooms/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success('Room deleted successfully');
      fetchOwnerRooms();
    } catch (error) {
      console.error('❌ Error deleting room:', error);
      toast.error('Failed to delete room');
    }
  };

  const handleAddRoom = async () => {
    try {
      await axios.post('http://localhost:8000/api/rooms/save', newRoom, {
        headers: { Authorization: `Bearer ${token}` }
      });
      toast.success('Room added successfully');
      setShowModal(false);
      setNewRoom({
        roomType: '',
        bedType: '',
        price: '',
        accomodate: 1,
        isAc: false,
        isAvailable: true,
        hotelId: ''
      });
      fetchOwnerRooms();
    } catch (error) {
      console.error('❌ Error adding room:', error);
      toast.error('Failed to add room');
    }
  };

  return (
    <div className="container mt-5" style={{ fontFamily: 'Segoe UI, sans-serif' }}>
      <ToastContainer />
      <div className="card shadow-sm border-0 p-4 rounded-4">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h2 className="fw-bold" style={{ color: '#0d6efd' }}>🛏️ Room Management</h2>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            <FaPlus /> Add Room
          </button>
        </div>

        {loading ? (
          <div className="text-center py-4">
            <div className="spinner-border text-primary" role="status" />
            <p className="mt-2">Loading rooms...</p>
          </div>
        ) : rooms.length === 0 ? (
          <p className="text-center text-muted">No rooms found for your hotels.</p>
        ) : (
          <div className="table-responsive">
            <table className="table table-bordered table-hover align-middle text-center">
              <thead className="table-light">
                <tr>
                  <th>ID</th>
                  <th>Room Type</th>
                  <th>Bed Type</th>
                  <th>Price</th>
                  <th>AC</th>
                  <th>Guests</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {rooms.map((room) => (
                  <tr key={room.id}>
                    <td>{room.id}</td>
                    <td>
                      {editingRoom?.id === room.id ? (
                        <input
                          name="roomType"
                          value={editingRoom.roomType}
                          onChange={handleInputChange}
                          className="form-control form-control-sm"
                        />
                      ) : (
                        room.roomType
                      )}
                    </td>
                    <td>
                      {editingRoom?.id === room.id ? (
                        <input
                          name="bedType"
                          value={editingRoom.bedType}
                          onChange={handleInputChange}
                          className="form-control form-control-sm"
                        />
                      ) : (
                        room.bedType
                      )}
                    </td>
                    <td>
                      {editingRoom?.id === room.id ? (
                        <input
                          type="number"
                          name="price"
                          value={editingRoom.price}
                          onChange={handleInputChange}
                          className="form-control form-control-sm"
                        />
                      ) : (
                        `₹${room.price}`
                      )}
                    </td>
                    <td>{room.isAc ? 'Yes' : 'No'}</td>
                    <td>{room.accomodate}</td>
                    <td className={`fw-semibold ${room.isAvailable ? 'text-success' : 'text-danger'}`}>
                      {room.isAvailable ? 'Available' : 'Unavailable'}
                    </td>
                    <td className="d-flex justify-content-center gap-2">
                      {editingRoom?.id === room.id ? (
                        <>
                          <button className="btn btn-sm btn-success" onClick={handleSaveClick}>
                            <FaSave /> Save
                          </button>
                          <button className="btn btn-sm btn-secondary" onClick={handleCancelClick}>
                            <FaTimes /> Cancel
                          </button>
                        </>
                      ) : (
                        <>
                          <button className="btn btn-sm btn-outline-primary" onClick={() => handleEditClick(room)}>
                            <FaEdit /> Edit
                          </button>
                          <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(room.id)}>
                            <FaTrash /> Delete
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Modal */}
        {showModal && (
          <div className="modal d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
            <div className="modal-dialog">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">Add Room</h5>
                  <button type="button" className="btn-close" onClick={() => setShowModal(false)}></button>
                </div>
                <div className="modal-body">
                  <input type="text" name="roomType" placeholder="Room Type" className="form-control mb-2"
                    value={newRoom.roomType} onChange={handleInputChange} />
                  <input type="text" name="bedType" placeholder="Bed Type" className="form-control mb-2"
                    value={newRoom.bedType} onChange={handleInputChange} />
                  <input type="number" name="price" placeholder="Price" className="form-control mb-2"
                    value={newRoom.price} onChange={handleInputChange} />
                  <input type="number" name="accomodate" placeholder="Guests" className="form-control mb-2"
                    value={newRoom.accomodate} onChange={handleInputChange} />
                  <input type="number" name="hotelId" placeholder="Hotel ID" className="form-control mb-2"
                    value={newRoom.hotelId} onChange={handleInputChange} />
                  <div className="form-check mb-2">
                    <input className="form-check-input" type="checkbox" name="isAc"
                      checked={newRoom.isAc} onChange={handleInputChange} />
                    <label className="form-check-label">AC</label>
                  </div>
                  <div className="form-check mb-2">
                    <input className="form-check-input" type="checkbox" name="isAvailable"
                      checked={newRoom.isAvailable} onChange={handleInputChange} />
                    <label className="form-check-label">Available</label>
                  </div>
                </div>
                <div className="modal-footer">
                  <button className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                  <button className="btn btn-primary" onClick={handleAddRoom}>Add Room</button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default OwnerManageRooms;
