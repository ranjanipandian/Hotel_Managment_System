import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import 'bootstrap/dist/css/bootstrap.min.css';

const OwnerHotels = () => {
  const [hotels, setHotels] = useState([]);
  const navigate = useNavigate();

  const token = localStorage.getItem('token');
  const ownerId = localStorage.getItem('userId');

  useEffect(() => {
    if (!token || !ownerId) {
      toast.error('Authentication failed. Please login again.');
      navigate('/login');
      return;
    }

    const fetchHotels = async () => {
      try {
        const response = await axios.get(`http://localhost:8000/api/hotels/owner/${ownerId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setHotels(response.data);
      } catch (error) {
        console.error('❌ Failed to load hotels:', error);
        toast.error('Failed to load hotels');
      }
    };

    fetchHotels();
  }, [token, ownerId, navigate]);

  const handleDelete = async (id) => {
    const confirm = window.confirm('Are you sure you want to delete this hotel?');
    if (!confirm) return;

    try {
      await axios.delete(`http://localhost:8000/api/hotels/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      toast.success('Hotel deleted successfully');
      setHotels(prev => prev.filter(h => h.id !== id));
    } catch (error) {
      console.error('❌ Failed to delete hotel:', error);
      toast.error('Failed to delete hotel');
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4 fw-bold text-primary">My Hotels</h2>

      <div className="text-end mb-3">
      
        <Link to="/owner/add-hotel" className="btn btn-primary">+ Add New Hotel</Link>
      </div>

      {hotels.length === 0 ? (
        <p className="text-center">No hotels found.</p>
      ) : (
        <div className="row row-cols-1 row-cols-md-3 g-4">
          {hotels.map((hotel) => (
            <div className="col" key={hotel.id}>
              <div className="card h-100 shadow-sm">
                <div className="card-body">
                  <h5 className="card-title">{hotel.name}</h5>
                  <p className="card-text">
                    <strong>City:</strong> {hotel.city}<br />
                    <strong>Location:</strong> {hotel.location}<br />
                    <strong>Phone:</strong> {hotel.phoneno}
                  </p>
                </div>
                <div className="card-footer d-flex justify-content-between">
                  <Link to={`/owner/edit-hotel/${hotel.id}`} className="btn btn-sm btn-primary">
                    Edit
                  </Link>
                  <button
                    onClick={() => handleDelete(hotel.id)}
                    className="btn btn-sm btn-danger"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default OwnerHotels;
