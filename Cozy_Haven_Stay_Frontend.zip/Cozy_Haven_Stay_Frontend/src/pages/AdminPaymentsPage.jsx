import React, { useEffect, useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const AdminPaymentsPage = () => {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    axios
      .get('http://localhost:8000/api/payments', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        setPayments(response.data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setError('Failed to fetch payment data.');
        setLoading(false);
      });
  }, []);

  return (
    <div className="container mt-5" style={{ fontFamily: 'Segoe UI, sans-serif' }}>
      <div className="card shadow p-4 border-0">
        <h3 className="text-center text-primary fw-bold mb-4">💳 Payment Management</h3>

        {loading ? (
          <div className="text-center py-4">
            <div className="spinner-border text-primary" role="status" />
            <p className="mt-2">Loading payments...</p>
          </div>
        ) : error ? (
          <p className="text-danger text-center mt-4">{error}</p>
        ) : (
          <div className="table-responsive">
            <table className="table table-striped align-middle text-center table-hover">
              <thead className="table-primary">
                <tr>
                  <th>Payment ID</th>
                  <th>Booking ID</th>
                  <th>Transaction ID</th>
                  <th>Date</th>
                  <th>Amount (₹)</th>
                  <th>Status</th>
                  <th>Payment Mode</th>
                </tr>
              </thead>
              <tbody>
                {payments.length > 0 ? (
                  payments.map((payment) => (
                    <tr key={payment.id}>
                      <td>{payment.id}</td>
                      <td>{payment.bookingId}</td>
                      <td>{payment.transactionId}</td>
                      <td>{new Date(payment.paymentDate).toLocaleString()}</td>
                      <td>{payment.totalAmount}</td>
                      <td>
                        <span className={`badge ${payment.status ? 'bg-success' : 'bg-danger'}`}>
                          {payment.status ? 'Successful' : 'Failed'}
                        </span>
                      </td>
                      <td>{payment.paymentMode}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="7">No payments found.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPaymentsPage;
