import React, { useEffect, useState } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';

const loadRazorpayScript = () => {
  return new Promise((resolve) => {
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
};

const PaymentPage = () => {
  const { bookingId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const query = new URLSearchParams(location.search);
  const amount = query.get('amount');

  const [booking, setBooking] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    axios
      .get(`http://localhost:8000/api/bookings/${bookingId}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => setBooking(res.data))
      .catch((err) => {
        console.error(err);
        setError('Failed to load booking details.');
      });
  }, [bookingId]);

  const handlePayment = async () => {
    const isLoaded = await loadRazorpayScript();
    if (!isLoaded) {
      alert('Failed to load Razorpay SDK. Please check your internet connection.');
      return;
    }

    const options = {
      key: 'rzp_test_ERCtB0qzBDT7zn', 
      amount: Number(amount) * 100,
      currency: 'INR',
      name: 'Cozy Haven Stay',
      description: `Payment for Booking #${bookingId}`,
      handler: async (response) => {
        const token = localStorage.getItem('token');
        try {
          await axios.post(
            `http://localhost:8000/api/payments/save`,
            {
              bookingId: Number(bookingId),
              transactionId: response.razorpay_payment_id,
              totalAmount: Number(amount),
              paymentDate: new Date().toISOString(),
              status: true,
              paymentMode: 'RAZORPAY',
            },
            {
              headers: { Authorization: `Bearer ${token}` },
            }
          );
          alert('Payment successful!');
          navigate('/search');
        } catch (err) {
          console.error('Failed to save payment:', err);
          alert('Payment was successful, but saving failed. Please contact support.');
          navigate('/search');
        }
      },
      prefill: {
        name: booking?.userName || '',
        email: booking?.userEmail || '',
      },
      notes: {
        bookingId: bookingId,
      },
      theme: {
        color: '#0d6efd', 
      },
    };

    const razorpay = new window.Razorpay(options);
    razorpay.open();
  };

  if (error) return <p className="text-danger text-center mt-4">{error}</p>;
  if (!booking) return <p className="text-center mt-4">Loading booking details…</p>;

  return (
    <div className="container d-flex justify-content-center align-items-center min-vh-100">
      <div className="card shadow-lg p-4" style={{ maxWidth: '600px', width: '100%' }}>
        <div className="d-flex justify-content-center">
          <h3 className="mb-4">
            <span className="badge bg-primary fs-4 shadow px-4 py-2 rounded-pill">
              Pay for Your Booking
            </span>
          </h3>
        </div>

        <ul className="list-group list-group-flush mb-3">
          <li className="list-group-item">
            <strong>Hotel:</strong> {booking.hotelName || 'Your Hotel'}
          </li>
          <li className="list-group-item">
            <strong>Check-In:</strong> {new Date(booking.checkInDate).toLocaleDateString()}
          </li>
          <li className="list-group-item">
            <strong>Check-Out:</strong> {new Date(booking.checkoutDate).toLocaleDateString()}
          </li>
          <li className="list-group-item">
            <strong>Total Amount:</strong> ₹{amount}
          </li>
        </ul>

        <button
          className="btn btn-primary w-100 btn-lg mb-2"
          onClick={handlePayment}
        >
          Pay Now ₹{amount}
        </button>

        <button
          className="btn btn-outline-danger w-100 btn-lg"
          onClick={() => navigate('/search')}
        >
          Cancel Payment
        </button>
      </div>
    </div>
  );
};

export default PaymentPage;
