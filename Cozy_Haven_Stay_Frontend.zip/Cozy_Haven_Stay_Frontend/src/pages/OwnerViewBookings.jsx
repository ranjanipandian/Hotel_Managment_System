import React, { useEffect, useState } from 'react';
import axios from 'axios';

const OwnerViewBookings = () => {
  const [bookings, setBookings] = useState([]);
  const ownerId = localStorage.getItem('ownerId');
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await axios.get(`http://localhost:8000/api/bookings/owner/${ownerId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setBookings(response.data);
      } catch (error) {
        console.error('Error fetching bookings:', error);
      }
    };

    fetchBookings();
  }, [ownerId, token]);

  const formatDate = (dateString) =>
    new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });

  return (
    <div className="container mt-5" style={{ fontFamily: 'Segoe UI, sans-serif' }}>
      <h2 className="text-center fw-bold mb-4" style={{ color: '#0d6efd' }}>
        🧾 Your Hotel Bookings
      </h2>

      {bookings.length === 0 ? (
        <p className="text-center text-muted">No bookings found.</p>
      ) : (
        <div className="card shadow-sm p-4 rounded-4">
          <div className="table-responsive">
            <table className="table table-bordered table-hover align-middle text-center">
              <thead className="table-light">
                <tr>
                  <th>Booking ID</th>
                  <th>Hotel</th>
                  <th>Check-in</th>
                  <th>Check-out</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((booking) => (
                  <tr key={booking.id}>
                    <td>{booking.id}</td>
                    <td>{booking.hotelName || 'N/A'}</td>
                    <td>{booking.checkInDate ? formatDate(booking.checkInDate) : 'N/A'}</td>
                    <td>{booking.checkoutDate ? formatDate(booking.checkoutDate) : 'N/A'}</td>
                    <td className={booking.isCancelled ? 'text-danger fw-semibold' : 'text-success fw-semibold'}>
                      {booking.isCancelled ? 'Cancelled' : 'Confirmed'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default OwnerViewBookings;
