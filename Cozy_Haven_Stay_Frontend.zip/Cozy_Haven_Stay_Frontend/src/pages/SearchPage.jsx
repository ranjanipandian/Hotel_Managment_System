import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './SearchPage.css';

const cityList = [
  { name: 'New Delhi and NCR', seed: 'delhi', count: '12,786 accommodations' },
  { name: 'Bangalore',         seed: 'bangalore', count: '5,372 accommodations' },
  { name: 'Mumbai',            seed: 'mumbai', count: '4,177 accommodations' },
  { name: 'Goa',               seed: 'goa', count: '9,254 accommodations' },
  { name: 'Hyderabad',         seed: 'hyderabad', count: '2,735 accommodations' },
  { name: 'Kashmir',           seed: 'kashmir', count: '1,798 accommodations' },
];

const normalizeCityName = (input) => {
  const normalized = input.trim().toLowerCase();

  if (['new delhi', 'delhi','NCR'].includes(normalized)) return 'New Delhi and NCR';
  if (normalized === 'bangalore' || normalized === 'bengaluru') return 'Bangalore';
  if (normalized === 'mumbai' || normalized === 'bombay') return 'Mumbai';
  if (normalized === 'goa') return 'Goa';
  if (normalized === 'hyderabad') return 'Hyderabad';
  if (normalized === 'kashmir' || normalized === 'srinagar') return 'Kashmir';

  return input;
};

const SearchPage = () => {
  const navigate = useNavigate();
  const [searchCity, setSearchCity] = useState('');

  const handleCityClick = (cityName) => {
    const normalizedCity = normalizeCityName(cityName);
    navigate(`/hotels/${encodeURIComponent(normalizedCity)}`);
  };

  const handleSearch = () => {
    if (searchCity.trim() !== '') {
      const normalizedCity = normalizeCityName(searchCity);
      navigate(`/hotels/${encodeURIComponent(normalizedCity)}`);
    }
  };

  return (
    <div className="search-page">
      
      {/* Search Bar */}
      <div className="search-bar">
        <input
          type="text"
          placeholder="Enter a destination or property"
          value={searchCity}
          onChange={(e) => setSearchCity(e.target.value)}
        />
        <input type="date" />
        <input type="date" />
        <select>
          <option>2 adults · 1 room</option>
          <option>1 adult · 1 room</option>
          <option>3 adults · 2 rooms</option>
        </select>
        <button className="btn-search" onClick={handleSearch}>SEARCH</button>
      </div>

      {/* Top Destinations */}
      <section>
        <h2>Top destinations in India</h2>
        <div className="destination-cards">
          {cityList.map((city, idx) => (
            <div
              key={idx}
              className="destination-card"
              onClick={() => handleCityClick(city.name)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && handleCityClick(city.name)}
              style={{ cursor: 'pointer' }}
            >
              <img
                src={`https://picsum.photos/seed/${city.seed}/600/400`}
                alt={city.name}
                referrerPolicy="no-referrer"
              />
              <p>
                <strong>{city.name}</strong><br />
                {city.count}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default SearchPage; 