import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const EditHotel = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [hotel, setHotel] = useState({
    name: '',
    city: '',
    location: '',
    phoneno: '',
    imageUrl: ''  
  });

  useEffect(() => {
    const fetchHotel = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(`http://localhost:8000/api/hotels/${id}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setHotel(response.data);
      } catch (error) {
        console.error('Failed to load hotel:', error);
        toast.error('Failed to fetch hotel details');
      }
    };
    fetchHotel();
  }, [id]);

  const handleChange = (e) => {
    setHotel({ ...hotel, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const role = localStorage.getItem('role');

      await axios.put(`http://localhost:8000/api/hotels/${id}`, hotel, {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (role === 'OWNER') {
        toast.success('Hotel updated successfully!');
        setTimeout(() => navigate('/owner/my-hotels'), 2000);
      } else {
        alert('Hotel updated successfully!');
        navigate('/admin/hotels');
      }

    } catch (error) {
      console.error('Update failed:', error);
      toast.error('Failed to update hotel');
    }
  };

  return (
    <div className="container mt-5">
      <h3>Edit Hotel</h3>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label>Hotel Name</label>
          <input
            type="text"
            name="name"
            value={hotel.name}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label>City</label>
          <input
            type="text"
            name="city"
            value={hotel.city}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label>Location</label>
          <input
            type="text"
            name="location"
            value={hotel.location}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label>Phone Number</label>
          <input
            type="text"
            name="phoneno"
            value={hotel.phoneno}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        <div className="mb-3">
          <label>Image URL</label>
          <input
            type="text"
            name="imageUrl"
            value={hotel.imageUrl}
            onChange={handleChange}
            className="form-control"
            placeholder="Paste image URL here"
          />
          {hotel.imageUrl && (
            <img
              src={hotel.imageUrl}
              alt="Preview"
              className="img-fluid mt-2"
              style={{ maxHeight: '200px', border: '1px solid #ccc' }}
            />
          )}
        </div>

        <button type="submit" className="btn btn-primary">Update Hotel</button>
      </form>
    </div>
  );
};

export default EditHotel;
