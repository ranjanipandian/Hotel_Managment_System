import React, { useEffect, useState, useCallback } from 'react';
import axios from 'axios';

const OwnerManageAmenities = () => {
  const [amenities, setAmenities] = useState([]);
  const [editAmenity, setEditAmenity] = useState(null);

  const ownerId = localStorage.getItem('ownerId');
  const token = localStorage.getItem('token');

  const fetchAmenities = useCallback(async () => {
    try {
      const res = await axios.get(`http://localhost:8000/api/amenities/owner/${ownerId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setAmenities(res.data);
    } catch (error) {
      console.error('Error fetching amenities:', error);
    }
  }, [ownerId, token]);

  useEffect(() => {
    fetchAmenities();
  }, [fetchAmenities]);

  const handleEdit = (amenity) => {
    setEditAmenity({ ...amenity });
  };

  const handleUpdate = async () => {
    try {
      await axios.put(
        `http://localhost:8000/api/amenities/${editAmenity.id}`,
        editAmenity,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      alert('Amenity updated successfully!');
      setEditAmenity(null);
      fetchAmenities(); 
    } catch (error) {
      console.error('Error updating amenity:', error);
      alert('Update failed.');
    }
  };

  return (
    <div className="container mt-5" style={{ fontFamily: 'Segoe UI, sans-serif' }}>
      <h2 className="text-center fw-bold mb-4" style={{ color: '#0d6efd' }}>
        🛎️ Amenities for Your Hotels
      </h2>

      {amenities.length > 0 ? (
        <div className="card shadow-sm p-4 rounded-4">
          <div className="table-responsive">
            <table className="table table-bordered table-hover align-middle text-center">
              <thead className="table-light">
                <tr>
                  <th>Hotel Name</th>
                  <th>Amenity</th>
                  <th>Description</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {amenities.map((item, index) => (
                  <tr key={index}>
                    <td>{item.hotelName}</td>
                    <td>{item.name}</td>
                    <td>{item.description || 'N/A'}</td>
                    <td>
                      <button
                        className="btn btn-sm btn-outline-primary"
                        onClick={() => handleEdit(item)}
                      >
                        Update
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <p className="text-center text-muted">No amenities found for your hotels.</p>
      )}

      {editAmenity && (
        <div className="card shadow mt-5 p-4 rounded-4">
          <h5 className="text-center fw-bold mb-4" style={{ color: '#0d6efd' }}>✏️ Edit Amenity</h5>
          <div className="mb-3">
            <label className="form-label">Amenity Name</label>
            <input
              type="text"
              className="form-control"
              value={editAmenity.name}
              onChange={(e) =>
                setEditAmenity({ ...editAmenity, name: e.target.value })
              }
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Description</label>
            <textarea
              className="form-control"
              rows={3}
              value={editAmenity.description}
              onChange={(e) =>
                setEditAmenity({ ...editAmenity, description: e.target.value })
              }
            ></textarea>
          </div>
          <div className="text-end">
            <button className="btn btn-success me-2" onClick={handleUpdate}>
              Save Changes
            </button>
            <button
              className="btn btn-outline-secondary"
              onClick={() => setEditAmenity(null)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default OwnerManageAmenities;
