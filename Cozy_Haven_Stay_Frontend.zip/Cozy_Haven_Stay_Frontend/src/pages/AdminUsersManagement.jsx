import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import { FaEdit, FaTrash, FaSave } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-toastify/dist/ReactToastify.css';

const ManageUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingUser, setEditingUser] = useState(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = () => {
    const token = localStorage.getItem('token');
    axios
      .get('http://localhost:8000/api/users', {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => {
        const data = res.data;
        if (Array.isArray(data)) setUsers(data);
        else if (Array.isArray(data.users)) setUsers(data.users);
        else if (Array.isArray(data.content)) setUsers(data.content);
        else setUsers([]);
      })
      .catch((err) => {
        console.error('❌ Error fetching users:', err);
        toast.error('Failed to load users');
      })
      .finally(() => setLoading(false));
  };

  const handleEditClick = (user) => setEditingUser({ ...user });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditingUser((prev) => ({ ...prev, [name]: value }));
  };

  const handleSaveClick = () => {
    const token = localStorage.getItem('token');
    axios
      .put(`http://localhost:8000/api/users/${editingUser.id}`, {
        userName: editingUser.name,
        phoneNumber: editingUser.phoneNumber,
        email: editingUser.email,
        role: editingUser.role,
      }, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then(() => {
        toast.success('User updated successfully');
        setUsers((prev) =>
          prev.map((user) =>
            user.id === editingUser.id ? { ...user, ...editingUser } : user
          )
        );
        setEditingUser(null);
      })
      .catch((error) => {
        console.error('❌ Error updating user:', error);
        toast.error('Failed to update user');
      });
  };

  const handleDeleteClick = (id) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;
    const token = localStorage.getItem('token');
    axios
      .delete(`http://localhost:8000/api/users/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then(() => {
        toast.success('User deleted successfully');
        setUsers((prev) => prev.filter((user) => user.id !== id));
      })
      .catch((error) => {
        console.error('❌ Error deleting user:', error);
        toast.error('Failed to delete user');
      });
  };

  const getRoleBadge = (role) => {
    const base = 'badge rounded-pill px-3 py-1';
    switch (role) {
      case 'ADMIN':
        return <span className={`${base} bg-primary`}>ADMIN</span>;
      case 'OWNER':
        return <span className={`${base} bg-success`}>OWNER</span>;
      default:
        return <span className={`${base} bg-secondary`}>GUEST</span>;
    }
  };

  return (
    <div className="container mt-5" style={{ fontFamily: 'Segoe UI, sans-serif' }}>
      <ToastContainer />
      <div className="card shadow p-4 border-0">
        <h3 className="text-center text-primary fw-bold mb-4">👥 USER MANAGEMENT</h3>

        {loading ? (
          <div className="text-center py-4">
            <div className="spinner-border text-primary" role="status" />
            <p>Loading users...</p>
          </div>
        ) : users.length === 0 ? (
          <p className="text-center">No users found.</p>
        ) : (
          <div className="table-responsive">
            <table className="table table-striped align-middle text-center table-hover">
              <thead className="table-primary">
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Role</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id}>
                    <td>{user.id}</td>
                    <td>
                      {editingUser?.id === user.id ? (
                        <input
                          name="name"
                          value={editingUser.name || ''}
                          onChange={handleInputChange}
                          className="form-control form-control-sm"
                        />
                      ) : (
                        user.name || 'N/A'
                      )}
                    </td>
                    <td>
                      {editingUser?.id === user.id ? (
                        <input
                          type="email"
                          name="email"
                          value={editingUser.email || ''}
                          onChange={handleInputChange}
                          className="form-control form-control-sm"
                        />
                      ) : (
                        user.email
                      )}
                    </td>
                    <td>
                      {editingUser?.id === user.id ? (
                        <input
                          name="phoneNumber"
                          value={editingUser.phoneNumber || ''}
                          onChange={handleInputChange}
                          className="form-control form-control-sm"
                        />
                      ) : (
                        user.phoneNumber || 'N/A'
                      )}
                    </td>
                    <td>
                      {editingUser?.id === user.id ? (
                        <select
                          name="role"
                          value={editingUser.role}
                          onChange={handleInputChange}
                          className="form-select form-select-sm"
                        >
                          <option value="GUEST">GUEST</option>
                          <option value="OWNER">OWNER</option>
                          <option value="ADMIN">ADMIN</option>
                        </select>
                      ) : (
                        getRoleBadge(user.role)
                      )}
                    </td>
                    <td className="d-flex justify-content-center gap-2">
                      {editingUser?.id === user.id ? (
                        <button
                          className="btn btn-sm btn-success"
                          onClick={handleSaveClick}
                          title="Save"
                        >
                          <FaSave /> Save
                        </button>
                      ) : (
                        <>
                          <button
                            className="btn btn-sm btn-outline-primary"
                            onClick={() => handleEditClick(user)}
                            title="Edit"
                          >
                            <FaEdit /> Edit
                          </button>
                          <button
                            className="btn btn-sm btn-outline-danger"
                            onClick={() => handleDeleteClick(user.id)}
                            title="Delete"
                          >
                            <FaTrash /> Delete
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default ManageUsers;
