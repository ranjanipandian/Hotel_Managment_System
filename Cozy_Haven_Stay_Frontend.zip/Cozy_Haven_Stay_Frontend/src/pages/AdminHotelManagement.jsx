import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import { FaEdit, FaTrash } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-toastify/dist/ReactToastify.css';

const ManageHotels = () => {
  const [hotels, setHotels] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchHotels();
  }, []);

  const fetchHotels = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:8000/api/hotels', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setHotels(response.data || []);
    } catch (error) {
      console.error('❌ Error fetching hotels:', error);
      toast.error('Failed to load hotels');
      setHotels([]);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this hotel?')) return;
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:8000/api/hotels/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success('Hotel deleted successfully');
      fetchHotels();
    } catch (error) {
      console.error('❌ Error deleting hotel:', error);
      toast.error('Failed to delete hotel');
    }
  };

  const handleEdit = (id) => {
    navigate(`/admin/edit-hotel/${id}`);
  };

  return (
    <div className="container mt-5" style={{ fontFamily: 'Segoe UI, sans-serif' }}>
      <ToastContainer />
      <div className="card shadow p-4 border-0">
        <h3 className="text-center text-primary fw-bold mb-4">🏨 Hotel Management</h3>

        {loading ? (
          <div className="text-center py-4">
            <div className="spinner-border text-primary" role="status" />
            <p className="mt-2">Loading hotels...</p>
          </div>
        ) : hotels.length === 0 ? (
          <p className="text-center">No hotels found.</p>
        ) : (
          <div className="table-responsive">
            <table className="table table-striped align-middle text-center table-hover">
              <thead className="table-primary">
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>City</th>
                  <th>Location</th>
                  <th>Phone No</th>
                  <th>Owner ID</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {hotels.map((hotel) => (
                  <tr key={hotel.id}>
                    <td>{hotel.id}</td>
                    <td>{hotel.name || 'N/A'}</td>
                    <td>{hotel.city || 'N/A'}</td>
                    <td>{hotel.location || 'N/A'}</td>
                    <td>{hotel.phoneno || 'N/A'}</td>
                    <td>{hotel.ownerId || 'N/A'}</td>
                    <td className="d-flex justify-content-center gap-2">
                      <button
                        className="btn btn-sm btn-outline-primary"
                        onClick={() => handleEdit(hotel.id)}
                        title="Edit"
                      >
                        <FaEdit /> Edit
                      </button>
                      <button
                        className="btn btn-sm btn-outline-danger"
                        onClick={() => handleDelete(hotel.id)}
                        title="Delete"
                      >
                        <FaTrash /> Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default ManageHotels;
