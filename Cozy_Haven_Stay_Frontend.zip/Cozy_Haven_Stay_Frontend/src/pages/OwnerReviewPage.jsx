import React, { useEffect, useState } from 'react';
import axios from 'axios';

const OwnerReviewPage = () => {
  const [reviews, setReviews] = useState([]);
  const ownerId = localStorage.getItem('ownerId');
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const response = await axios.get(`http://localhost:8000/api/reviews/owner/${ownerId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setReviews(response.data);
      } catch (error) {
        console.error('Failed to fetch reviews:', error);
      }
    };

    if (ownerId && token) fetchReviews();
  }, [ownerId, token]);

  return (
    <div className="container mt-5" style={{ fontFamily: 'Segoe UI, sans-serif' }}>
      <h2 className="text-center fw-bold mb-4" style={{ color: '#0d6efd' }}>
        💬 Guest Reviews for Your Hotels
      </h2>

      {reviews.length === 0 ? (
        <p className="text-center text-muted">No reviews available.</p>
      ) : (
        <div className="card shadow-sm p-4 rounded-4">
          <div className="table-responsive">
            <table className="table table-bordered table-hover align-middle text-center">
              <thead className="table-light">
                <tr>
                  <th>Guest</th>
                  <th>Hotel</th>
                  <th>Rating</th>
                  <th>Comment</th>
                </tr>
              </thead>
              <tbody>
                {reviews.map((review, index) => (
                  <tr key={index}>
                    <td>{review.guestName || 'Anonymous'}</td>
                    <td>{review.hotelName}</td>
                    <td>{review.rating} ⭐</td>
                    <td>{review.comment}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default OwnerReviewPage;
