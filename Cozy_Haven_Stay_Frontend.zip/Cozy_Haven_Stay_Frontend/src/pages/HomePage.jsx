import './HomePage.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FaHotel } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
  const navigate = useNavigate();

  return (
    <div className="homepage-container">
      <div className="overlay text-center p-4">
        <div className="logo-section d-flex justify-content-center align-items-center mb-4 animate-pop">
          <FaHotel size={48} className="text-glow me-2" />
          <h1 className="m-0 fw-bold text-glow">Cozy Haven Stay</h1>
        </div>

        <h2 className="fw-semibold text-light mb-3 fade-in">Welcome to Your Home Away From Home </h2>
        <p className="lead text-light fade-in">
          Discover, book, and relax at the most comfortable stays around the world 
        </p>

        <button
          onClick={() => navigate('/about')}
          className="btn get-started-btn mt-4"
        >
          Get Started
        </button>
      </div>
    </div>
  );
};

export default HomePage;
