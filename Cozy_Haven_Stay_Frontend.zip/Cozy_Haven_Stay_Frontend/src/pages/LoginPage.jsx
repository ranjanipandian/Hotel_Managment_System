import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './LoginPage.css';

const LoginPage = () => {
  const [credentials, setCredentials] = useState({ email: '', password: '' });
  const navigate = useNavigate();

  const handleChange = (e) => {
    setCredentials({ 
      ...credentials, 
      [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:8000/api/auth/login', credentials);
      console.log("Login response:", res.data);

      const { accessToken, userDto } = res.data;

      if (!accessToken || !userDto) {
        alert('Invalid response from server');
        return;
      }

      localStorage.setItem('token', accessToken);
      localStorage.setItem('role', userDto.role);
      localStorage.setItem('username', userDto.userName);
      localStorage.setItem('userId', userDto.id);

   

      alert('Login successful!');

      switch (userDto.role) {
        case 'ADMIN':
          navigate('/admin-dashboard');
          break;
        case 'OWNER':
          navigate('/owner-dashboard');
          localStorage.setItem('ownerId', userDto.id);
          break;
        case 'GUEST':
          navigate('/search');
          break;
        default:
          navigate('/');
      }
    } catch (error) {
      console.error('Login failed', error);
      alert('Login failed! Please check your credentials.');
    }
  };

  return (
    <div className="login-page">
      <nav className="login-nav">
        <h2>Cozy Haven</h2>
      </nav>

      <div className="login-banner">  
        <div className="login-form-container">
          <form onSubmit={handleSubmit} className="login-form">
            <img
              src="https://cdn-icons-png.flaticon.com/512/235/235861.png"
              alt="Hotel Icon"
              className="login-logo"
            />
            <h3>Login to Cozy Haven</h3>

            <div className="input-group">
              <label>Email</label>
              <input
                type="email"
                name="email"
                placeholder="Enter your email"
                value={credentials.email}
                onChange={handleChange}
                required
              />
            </div>

            <div className="input-group">
              <label>Password</label>
              <input
                type="password"
                name="password"
                placeholder="Enter your password"
                value={credentials.password}
                onChange={handleChange}
                required
              />
            </div>

            <div className="remember-me">
              <input type="checkbox" id="remember" />
              <label htmlFor="remember">Stay signed in</label>
            </div>

            <button type="submit" className="login-button">Sign In</button>

            <p className="signup-link">
              Don’t have an account? <a href="/register">Sign Up here</a>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
