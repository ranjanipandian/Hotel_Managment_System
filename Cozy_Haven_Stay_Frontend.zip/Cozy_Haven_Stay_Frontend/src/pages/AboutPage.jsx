import React, { useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const AboutPage = () => {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (location.hash === '#contact') {
      const contactSection = document.getElementById('contact');
      if (contactSection) {
        contactSection.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [location]);

  const handleBookNow = () => {
    const isLoggedIn = localStorage.getItem('token');
    if (isLoggedIn) {
      navigate('/book');
    } else {
      navigate('/login');
    }
  };
  const handleContactSubmit = async (e) => {
    e.preventDefault();

    const name = e.target.name.value;
    const email = e.target.email.value;
    const message = e.target.message.value;

    try {
      await axios.post('http://localhost:8000/api/contact/send', {
        name,
        email,
        message,
      });

      toast.success('Message sent successfully!');
      e.target.reset(); 
    } catch (error) {
      console.error('Contact form submission failed:', error);
      toast.error('Failed to send message. Please try again later.');
    }
  };

  return (
    <div className="container py-5">

      {/* About */}
      <div className="row align-items-center mb-5">
        <div className="col-md-6 mb-4 mb-md-0">
          <img
            src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=800&q=80"
            className="img-fluid rounded shadow"
            alt="Cozy Hotel"
          />
        </div>
        <div className="col-md-6">
          <h2 className="display-5 fw-bold text-primary">About Cozy Haven</h2>
          <p className="fs-5 text-muted">
            Cozy Haven offers premium, handpicked stays for travelers who value comfort and style.
          </p>
          <p className="text-secondary">
            With our user-friendly booking platform and excellent customer support,
            your perfect stay is just a click away.
          </p>
          <button className="btn btn-outline-primary btn-lg mt-3" onClick={handleBookNow}>
            Book Now
          </button>
        </div>
      </div>

      {/* Contact Us */}
      <div id="contact" className="contact-section bg-light rounded p-5 shadow">
        <h3 className="text-center fw-bold mb-4 text-dark">📩 Contact Us</h3>
        <p className="text-center mb-4 text-muted">
          Got a question or feedback? We’d love to hear from you!
        </p>
        <form className="mx-auto" style={{ maxWidth: '600px' }} onSubmit={handleContactSubmit}>
          <div className="mb-3">
            <label htmlFor="name" className="form-label">Name</label>
            <input type="text" id="name" name="name" className="form-control" placeholder="Your Name" required />
          </div>
          <div className="mb-3">
            <label htmlFor="email" className="form-label">Email</label>
            <input type="email" id="email" name="email" className="form-control" placeholder="Your Email" required />
          </div>
          <div className="mb-4">
            <label htmlFor="message" className="form-label">Message</label>
            <textarea id="message" name="message" className="form-control" rows="4" placeholder="Type your message..." required></textarea>
          </div>
          <button type="submit" className="btn btn-warning w-100">Send Message</button>
        </form>
      </div>

      <ToastContainer position="top-center" autoClose={3000} />
    </div>
  );
};

export default AboutPage;
