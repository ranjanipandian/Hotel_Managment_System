import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { FaTrash, FaBook } from 'react-icons/fa';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const AdminBookingManagement = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:8000/api/bookings', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setBookings(response.data || []);
    } catch (error) {
      console.error('Error fetching bookings:', error);
      toast.error('Failed to fetch bookings');
    } finally {
      setLoading(false);
    }
  };

  const cancelBooking = async (bookingId) => {
    if (!window.confirm('Are you sure you want to cancel this booking?')) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:8000/api/bookings/${bookingId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success('Booking cancelled');
      setBookings(prev => prev.filter(b => b.id !== bookingId));
    } catch (error) {
      console.error('Error cancelling booking:', error);
      toast.error('Failed to cancel booking');
    }
  };

  return (
    <div className="container mt-5" style={{ fontFamily: 'Segoe UI, sans-serif' }}>
      <ToastContainer />
      <div className="card shadow p-4 border-0">
        <h3 className="text-center text-primary fw-bold mb-4">
          <FaBook className="me-2 text-danger" />
          Booking Management
        </h3>

        {loading ? (
          <div className="text-center py-4">
            <div className="spinner-border text-primary" role="status" />
            <p className="mt-2">Loading bookings...</p>
          </div>
        ) : bookings.length === 0 ? (
          <p className="text-center">No bookings found.</p>
        ) : (
          <div className="table-responsive">
            <table className="table table-striped align-middle text-center table-hover">
              <thead className="table-primary">
                <tr>
                  <th>Booking ID</th>
                  <th>User ID</th>
                  <th>Room ID</th>
                  <th>Check-In</th>
                  <th>Check-Out</th>
                  <th>No. of Guests</th>
                  <th>Status</th>
                  <th>Total (₹)</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map(booking => (
                  <tr key={booking.id}>
                    <td>{booking.id}</td>
                    <td>{booking.userId}</td>
                    <td>{booking.roomId}</td>
                    <td>{booking.checkInDate}</td>
                    <td>{booking.checkoutDate}</td>
                    <td>{booking.noOfAdults + booking.noOfChildren}</td>
                    <td>
                      <span className={`badge ${booking.cancelled ? 'bg-danger' : 'bg-success'}`}>
                        {booking.cancelled ? 'Cancelled' : 'Confirmed'}
                      </span>
                    </td>
                    <td>₹{booking.totalAmount}</td>
                    <td>
                      {!booking.cancelled && (
                        <button
                          className="btn btn-sm btn-outline-danger"
                          onClick={() => cancelBooking(booking.id)}
                          title="Cancel Booking"
                        >
                          <FaTrash /> Cancel
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminBookingManagement;
