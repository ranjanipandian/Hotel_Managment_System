import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { FaTrash, FaToggleOn, FaToggleOff, FaBed } from 'react-icons/fa';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const ManageRooms = () => {
  const [rooms, setRooms] = useState([]);

  const fetchRooms = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:8000/api/rooms', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setRooms(response.data);
    } catch (error) {
      console.error('Error fetching rooms:', error);
      toast.error('Failed to fetch rooms');
    }
  };

  const deleteRoom = async (roomId) => {
    if (!window.confirm('Are you sure you want to delete this room?')) return;
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:8000/api/rooms/${roomId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success('Room deleted successfully');
      setRooms(prev => prev.filter(room => room.id !== roomId));
    } catch (error) {
      console.error('Error deleting room:', error);
      toast.error('Failed to delete room');
    }
  };

  const toggleRoomStatus = async (roomId, currentStatus) => {
    try {
      const token = localStorage.getItem('token');
      const newStatus = !currentStatus;

      await axios.patch(
        `http://localhost:8000/api/rooms/${roomId}/status`,
        {},
        {
          headers: { Authorization: `Bearer ${token}` },
          params: { isAvailable: newStatus },
        }
      );

      toast.success('Room status updated');
      setRooms(prevRooms =>
        prevRooms.map(room =>
          room.id === roomId ? { ...room, isAvailable: newStatus } : room
        )
      );
    } catch (error) {
      console.error('Error updating room status:', error);
      toast.error('Failed to update status');
    }
  };

  useEffect(() => {
    fetchRooms();
  }, []);

  return (
    <div className="container mt-5" style={{ fontFamily: 'Segoe UI, sans-serif' }}>
      <ToastContainer />
      <div className="card shadow p-4 border-0">
        <h3 className="text-center text-primary fw-bold mb-4">
          <FaBed className="me-2 text-danger" />
          Room Management
        </h3>

        {rooms.length === 0 ? (
          <p className="text-center">No rooms available.</p>
        ) : (
          <div className="table-responsive">
            <table className="table table-striped align-middle text-center table-hover">
              <thead className="table-primary">
                <tr>
                  <th>ID</th>
                  <th>Room Type</th>
                  <th>Price</th>
                  <th>Capacity</th>
                  <th>Availability</th>
                  <th>Hotel ID</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {rooms.map(room => (
                  <tr key={room.id}>
                    <td>{room.id}</td>
                    <td>{room.roomType}</td>
                    <td>₹{room.price}</td>
                    <td>{room.accomodate}</td>
                    <td>
                      <span className={`badge ${room.isAvailable ? 'bg-success' : 'bg-danger'}`}>
                        {room.isAvailable ? 'Available' : 'Unavailable'}
                      </span>
                    </td>
                    <td>{room.hotelId}</td>
                    <td className="d-flex justify-content-center gap-2">
                      <button
                        className="btn btn-sm btn-outline-warning"
                        onClick={() => toggleRoomStatus(room.id, room.isAvailable)}
                        title="Toggle Availability"
                      >
                        {room.isAvailable ? <FaToggleOff /> : <FaToggleOn />} Toggle
                      </button>
                      <button
                        className="btn btn-sm btn-outline-danger"
                        onClick={() => deleteRoom(room.id)}
                        title="Delete Room"
                      >
                        <FaTrash /> Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default ManageRooms;
