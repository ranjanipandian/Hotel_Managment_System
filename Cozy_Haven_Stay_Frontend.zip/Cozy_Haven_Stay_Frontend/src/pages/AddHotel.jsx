import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import 'bootstrap/dist/css/bootstrap.min.css';

const AddHotel = () => {
  const navigate = useNavigate();

  const [hotel, setHotel] = useState({
    name: '',
    location: '',
    city: '',
    phoneno: '',
    ownerId: ''
  });

  useEffect(() => {
    const userId = localStorage.getItem('userId');
    if (userId) {
      setHotel(prev => ({ ...prev, ownerId: Number(userId) }));
    } else {
      toast.error('User not logged in. Please login again.');
      navigate('/login');
    }
  }, [navigate]); 

  const handleChange = (e) => {
    const { name, value } = e.target;
    setHotel(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');

      await axios.post('http://localhost:8000/api/hotels/save', hotel, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      toast.success('Hotel added successfully!');
      navigate('/owner/my-hotels');
    } catch (error) {
      console.error('Failed to add hotel:', error.response?.data || error.message);
      toast.error('Failed to add hotel. Please check your input and try again.');
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-center">Add New Hotel</h2>
      <form onSubmit={handleSubmit} className="mx-auto" style={{ maxWidth: '600px' }}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Hotel Name</label>
          <input
            type="text"
            className="form-control"
            id="name"
            name="name"
            value={hotel.name}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="location" className="form-label">Address / Location</label>
          <input
            type="text"
            className="form-control"
            id="location"
            name="location"
            value={hotel.location}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="city" className="form-label">City</label>
          <input
            type="text"
            className="form-control"
            id="city"
            name="city"
            value={hotel.city}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="phoneno" className="form-label">Phone Number</label>
          <input
            type="text"
            className="form-control"
            id="phoneno"
            name="phoneno"
            value={hotel.phoneno}
            onChange={handleChange}
            placeholder="+91-9876543210"
            required
          />
        </div>

        <input type="hidden" name="ownerId" value={hotel.ownerId} />

        <div className="text-center">
          <button type="submit" className="btn btn-success">Add Hotel</button>
        </div>
      </form>
    </div>
  );
};

export default AddHotel;
