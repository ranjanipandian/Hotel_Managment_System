import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminReviewModeration = () => {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReviewsWithNames = async () => {
      try {
        const token = localStorage.getItem('token');
        const { data: reviewList } = await axios.get(
          'http://localhost:8000/api/reviews',
          { headers: { Authorization: `Bearer ${token}` } }
        );

        const enriched = await Promise.all(
          reviewList.map(async (rev) => {
            let hotelName = 'N/A';
            try {
              const { data: hotelDto } = await axios.get(
                `http://localhost:8000/api/hotels/${rev.hotelId}`,
                { headers: { Authorization: `Bearer ${token}` } }
              );
              hotelName = hotelDto.name || 'N/A';
            } catch (err) {
              console.error(`Error fetching hotel ${rev.hotelId}`, err);
            }
            return { ...rev, hotelName };
          })
        );

        setReviews(enriched);
      } catch (err) {
        console.error('Error loading reviews:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchReviewsWithNames();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this review?')) return;
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:8000/api/reviews/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setReviews((prev) => prev.filter((r) => r.id !== id));
      alert('Review deleted successfully!');
    } catch (err) {
      console.error('Delete failed:', err);
      alert('Failed to delete review.');
    }
  };

  return (
    <div className="container mt-5" style={{ fontFamily: 'Segoe UI, sans-serif' }}>
      <div className="card shadow p-4 border-0">
        <h3 className="text-center text-primary fw-bold mb-4">📝 Review Moderation</h3>

        {loading ? (
          <div className="text-center py-4">
            <div className="spinner-border text-primary" role="status" />
            <p className="mt-2">Loading reviews...</p>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="table table-striped align-middle text-center table-hover">
              <thead className="table-primary">
                <tr>
                  <th>Review ID</th>
                  <th>User ID</th>
                  <th>Hotel Name</th>
                  <th>Rating</th>
                  <th>Comment</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {reviews.length > 0 ? (
                  reviews.map((r) => (
                    <tr key={r.id}>
                      <td>{r.id}</td>
                      <td>{r.userId}</td>
                      <td>{r.hotelName}</td>
                      <td>{r.rating}</td>
                      <td>{r.comment}</td>
                      <td>
                        <button
                          className="btn btn-sm btn-outline-danger"
                          onClick={() => handleDelete(r.id)}
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-muted">No reviews found.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminReviewModeration;
