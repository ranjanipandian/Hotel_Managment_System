import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const BookingPage = () => {
  const { roomId } = useParams();
  const navigate = useNavigate();
  const [room, setRoom] = useState(null);
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    axios.get(`http://localhost:8000/api/rooms/${roomId}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(res => setRoom(res.data))
    .catch(err => {
      setError('Failed to load room details.');
      console.error(err);
    });
  }, [roomId]);

  const calculateNights = (start, end) => {
    const startDate = new Date(start);
    const endDate = new Date(end);
    const diffTime = endDate - startDate;
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const handleBooking = () => {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');

    if (!userId || isNaN(userId) || Number(userId) <= 0) {
      setError('Invalid user session. Please log in again.');
      console.error('Invalid userId from localStorage:', userId);
      return;
    }

    if (!checkIn || !checkOut) {
      setError('Please select both check-in and check-out dates.');
      return;
    }

    const nights = calculateNights(checkIn, checkOut);
    if (nights <= 0) {
      setError('Check-out must be after check-in.');
      return;
    }

    const totalAmount = nights * room.price;

    const payload = {
      noOfRooms: 1,
      noOfAdults: 2,
      noOfChildren: 0,
      checkInDate: checkIn,
      checkoutDate: checkOut,
      totalAmount: totalAmount,
      isCancelled: false,
      cancellationDate: null,
      cancellationReason: null,
      userId: Number(userId),    
      roomId: Number(roomId)     
    };

    console.log('Booking Payload:', payload);

    axios.post(`http://localhost:8000/api/bookings/save`, payload, {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(res => {
      const bookingId = res.data.id;
      navigate(`/payments/${bookingId}?amount=${totalAmount}`);
    })
    .catch(err => {
      setError('Booking failed.');
      console.error(err);
    });
  };

  if (error) return <div className="text-danger text-center mt-4">{error}</div>;
  if (!room) return <div className="text-center mt-4">Loading room details…</div>;

  return (
    <div className="container py-5">
      <h2 className="mb-4">Book Room: {room.roomType}</h2>
      <p><strong>Price per Night:</strong> ₹{room.price}</p>
      <p><strong>Accommodates:</strong> {room.accomodate} person(s)</p>

      <div className="mb-3">
        <label>Check-In Date:</label>
        <input type="date" value={checkIn} onChange={e => setCheckIn(e.target.value)} className="form-control" />
      </div>

      <div className="mb-3">
        <label>Check-Out Date:</label>
        <input type="date" value={checkOut} onChange={e => setCheckOut(e.target.value)} className="form-control" />
      </div>

      <button className="btn btn-success" onClick={handleBooking}>Proceed to Payment</button>
    </div>
  );
};

export default BookingPage;
