import { useEffect, useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './UserProfile.css';

const UserProfile = () => {
  const [user, setUser] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({
    userName: "",
    email: "",
    phoneNumber: ""
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    axios.get("http://localhost:8000/api/users/me", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`
      }
    })
      .then((res) => {
        setUser(res.data);
        setFormData({
          userName: res.data.userName || res.data.name || "",
          email: res.data.email || "",
          phoneNumber: res.data.phoneNumber || ""
        });
      })
      .catch((err) => console.error("User fetch failed", err));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    setLoading(true);
    axios.put("http://localhost:8000/api/users/update-profile", {
      userName: formData.userName,
      email: formData.email,
      phoneNumber: formData.phoneNumber
    }, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`
      }
    })
      .then((res) => {
        setUser(res.data);
        setFormData({
          userName: res.data.userName || res.data.name || "",
          email: res.data.email || "",
          phoneNumber: res.data.phoneNumber || ""
        });
        setEditMode(false);
        setLoading(false);
        toast.success("Profile updated successfully!");
      })
      .catch((err) => {
        console.error("Update failed", err);
        toast.error("Failed to update profile.");
        setLoading(false);
      });
  };

  return (
    <div className="profile-container">
      <div className="profile-card shadow">
        <div className="text-center mb-4">
          <img
            src="https://cdn-icons-png.flaticon.com/512/149/149071.png"
            alt="User"
            className="profile-image"
          />
          <h2 className="profile-title">User Profile</h2>
        </div>

        {user ? (
          <div className="user-info">
            <div className="mb-3">
              <label>Name:</label>
              {editMode ? (
                <input
                  type="text"
                  name="userName"
                  className="form-control"
                  value={formData.userName}
                  onChange={handleChange}
                />
              ) : (
                <p>{user.userName || user.name}</p>
              )}
            </div>

            <div className="mb-3">
              <label>Email:</label>
              {editMode ? (
                <input
                  type="email"
                  name="email"
                  className="form-control"
                  value={formData.email}
                  onChange={handleChange}
                />
              ) : (
                <p>{user.email}</p>
              )}
            </div>

            <div className="mb-3">
              <label>Phone Number:</label>
              {editMode ? (
                <input
                  type="text"
                  name="phoneNumber"
                  className="form-control"
                  value={formData.phoneNumber}
                  onChange={handleChange}
                />
              ) : (
                <p>{user.phoneNumber || "N/A"}</p>
              )}
            </div>

            <p><strong>User ID:</strong> {user.id}</p>

            <div className="text-center mt-4">
              {editMode ? (
                <>
                  <button
                    className="btn btn-success me-2"
                    onClick={handleSave}
                    disabled={loading}
                  >
                    {loading ? "Saving..." : "Save"}
                  </button>
                  <button
                    className="btn btn-secondary"
                    onClick={() => setEditMode(false)}
                    disabled={loading}
                  >
                    Cancel
                  </button>
                </>
              ) : (
                <button className="btn btn-primary" onClick={() => setEditMode(true)}>Edit Profile</button>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center text-muted">Loading profile...</div>
        )}
      </div>

      <ToastContainer position="top-center" autoClose={3000} />
    </div>
  );
};

export default UserProfile;
