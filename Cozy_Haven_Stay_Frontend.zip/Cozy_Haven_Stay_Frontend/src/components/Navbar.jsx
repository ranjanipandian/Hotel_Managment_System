import { NavLink, useNavigate } from 'react-router-dom';
import { FaSignOutAlt, FaUserCircle, FaHotel, FaInfoCircle, FaEnvelope } from 'react-icons/fa';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './Navbar.css';

const Navbar = () => {
  const navigate = useNavigate();
  const isLoggedIn = !!localStorage.getItem('token');

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');

    toast.success("Logged out successfully!", {
      position: "top-center",
      autoClose: 2000,
      hideProgressBar: false,
      pauseOnHover: false,
      draggable: false,
      progress: undefined,
      theme: "dark"
    });

    setTimeout(() => {
      navigate('/login');
    }, 2200);
  };

  const handleProfile = () => {
    navigate('/profile');
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark px-4">
      <div className="d-flex align-items-center navbar-brand text-warning fw-bold">
        <FaHotel size={24} className="me-2 text-logo-glow" />
        <NavLink className="text-warning text-decoration-none" to="/">
          Cozy Haven
        </NavLink>
      </div>

      <div className="ms-auto d-flex align-items-center">
        <NavLink
          to="/"
          className={({ isActive }) =>
            `nav-link mx-2 d-flex align-items-center ${isActive ? 'text-warning fw-bold' : 'text-light'}`
          }
        >
          Home
        </NavLink>

        <NavLink
          to="/about"
          className={({ isActive }) =>
            `nav-link mx-2 d-flex align-items-center ${isActive ? 'text-warning fw-bold' : 'text-light'}`
          }
        >
          <FaInfoCircle className="me-1" />
          About Us
        </NavLink>

        <a
          href="/about#contact"
          className="nav-link mx-2 d-flex align-items-center text-light"
        >
          <FaEnvelope className="me-1" />
          Contact Us
        </a>

        {!isLoggedIn ? (
          <>
            <NavLink
              to="/login"
              className={({ isActive }) =>
                `nav-link mx-2 ${isActive ? 'text-warning fw-bold' : 'text-light'}`
              }
            >
              Sign In
            </NavLink>
            <NavLink
              to="/register"
              className={({ isActive }) =>
                `nav-link mx-2 ${isActive ? 'text-warning fw-bold' : 'text-light'}`
              }
            >
              Sign Up
            </NavLink>
          </>
        ) : (
          <>
            <FaUserCircle
              size={22}
              className="text-warning mx-3"
              style={{ cursor: 'pointer' }}
              onClick={handleProfile}
              title="User Profile"
            />
            <button
              onClick={handleLogout}
              className="btn btn-outline-warning btn-sm"
              title="Logout"
            >
              <FaSignOutAlt />
            </button>
            <ToastContainer />
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
