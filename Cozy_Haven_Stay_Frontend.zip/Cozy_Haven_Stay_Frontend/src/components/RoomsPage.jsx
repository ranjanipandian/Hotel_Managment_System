import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import './RoomsPage.css';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const RoomsPage = () => {
  const { hotelId } = useParams();
  const [rooms, setRooms] = useState([]);
  const [amenities, setAmenities] = useState([]);
  const [hotelName, setHotelName] = useState('');
  const [reviews, setReviews] = useState([]);
  const [comment, setComment] = useState('');
  const [rating, setRating] = useState(5);
  const [refresh, setRefresh] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');

    axios
      .get(`http://localhost:8000/api/hotels/${hotelId}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => setHotelName(res.data.name))
      .catch((err) => console.error('Hotel fetch error:', err));

    axios
      .get(`http://localhost:8000/api/rooms`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => {
        const filteredRooms = res.data.filter(
          (room) => room.hotelId === parseInt(hotelId, 10)
        );
        setRooms(filteredRooms);
      })
      .catch((err) => console.error('Room fetch error:', err));

    axios
      .get(`http://localhost:8000/api/amenities/hotel/${hotelId}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => setAmenities(res.data))
      .catch((err) => console.error('Amenities fetch error:', err));

    axios
      .get(`http://localhost:8000/api/reviews/hotel/${hotelId}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => setReviews(res.data))
      .catch((err) => console.error('Review fetch error:', err));
  }, [hotelId, refresh]);

  const handleSubmitReview = (e) => {
    e.preventDefault();
    const userId = localStorage.getItem('userId');

    axios
      .post(
        'http://localhost:8000/api/reviews/save',
        {
          user: { id: userId },
          hotel: { id: hotelId },
          comment,
          rating,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        }
      )
      .then(() => {
        setComment('');
        setRating(5);
        setRefresh(!refresh);
        toast.success('Thanks for your review!');
      })
      .catch((err) => {
        console.error('Review submit error:', err);
        toast.error('Something went wrong. Please try again.');
      });
  };

  return (
    <div className="container py-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="text-primary">Available Rooms – {hotelName}</h2>
        <Link to="/search" className="btn btn-secondary">
          ← Back to Cities
        </Link>
      </div>

      <h4 className="mt-4">Amenities Available:</h4>
      {amenities.length > 0 ? (
        <div className="d-flex flex-wrap gap-2 mb-4">
          {amenities.map((amenity) => (
            <span key={amenity.id} className="badge bg-info text-dark p-2">
              {amenity.name}
            </span>
          ))}
        </div>
      ) : (
        <p>No amenities listed for this hotel.</p>
      )}

      {rooms.length === 0 ? (
        <p className="text-center">No available rooms in this hotel.</p>
      ) : (
        <div className="row">
          {rooms.map((room) => (
            <div className="col-md-4 mb-4" key={room.id}>
              <div className="card h-100 shadow room-card">
                <div className="card-body d-flex flex-column">
                  <h5 className="card-title">{room.roomType}</h5>
                  <p className="card-text">Capacity: {room.capacity} person(s)</p>
                  <p className="card-text text-success">₹{room.price} per night</p>
                  <p className="card-text text-muted">
                    Available: {room.isAvailable ? 'Yes' : 'No'}
                  </p>
                  <button
                    className="btn btn-success mt-auto"
                    onClick={() => navigate(`/book/${room.id}`)}
                  >
                    Book Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <hr className="my-5" />
      <h3>Hotel Reviews</h3>

      {reviews.length === 0 ? (
        <p>No reviews yet. Be the first to write one!</p>
      ) : (
        <ul className="list-group mb-4">
          {reviews.map((review) => (
            <li key={review.id} className="list-group-item">
              <strong>Rating:</strong>{' '}
              {[...Array(5)].map((_, i) => (
                <span key={i} style={{ color: i < review.rating ? 'gold' : 'lightgray' }}>
                  ★
                </span>
              ))}<br />
              <strong>Comment:</strong> {review.comment}
            </li>
          ))}
        </ul>
      )}

      <h5 className="mt-4">Add Your Review</h5>
      <form onSubmit={handleSubmitReview}>
        <div className="mb-3">
          <label className="form-label">Comment</label>
          <textarea
            className="form-control"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Rating</label>
          <div>
            {[1, 2, 3, 4, 5].map((star) => (
              <span
                key={star}
                onClick={() => setRating(star)}
                style={{
                  cursor: 'pointer',
                  color: star <= rating ? 'gold' : 'lightgray',
                  fontSize: '1.5rem',
                }}
              >
                ★
              </span>
            ))}
          </div>
        </div>
        <button type="submit" className="btn btn-primary">
          Submit Review
        </button>
      </form>

      <ToastContainer position="top-center" autoClose={3000} />
    </div>
  );
};

export default RoomsPage;
