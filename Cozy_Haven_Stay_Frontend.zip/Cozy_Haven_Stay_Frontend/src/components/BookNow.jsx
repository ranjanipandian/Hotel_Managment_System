import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const BookNow = () => {
  const navigate = useNavigate();

  const [bookingData, setBookingData] = useState({
    userId: '',
    roomId: '',
    checkIn: '',
    checkOut: '',
    numberOfGuests: '',
  });

  const handleChange = (e) => {
    setBookingData({ ...bookingData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    console.log('Booking Details:', bookingData);

    navigate(`/book/${bookingData.roomId}`);
  };

  return (
    <div className="container mt-5 mb-5">
      <div className="card shadow-lg">
        <div className="card-body p-5">
          <h2 className="mb-4 text-center text-primary">Book Your Stay at Cozy Haven 🛏️</h2>
          
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label htmlFor="userId" className="form-label">User ID</label>
              <input
                type="text"
                className="form-control"
                id="userId"
                name="userId"
                placeholder="Enter your user ID"
                value={bookingData.userId}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3">
              <label htmlFor="roomId" className="form-label">Room ID</label>
              <input
                type="text"
                className="form-control"
                id="roomId"
                name="roomId"
                placeholder="Enter Room ID"
                value={bookingData.roomId}
                onChange={handleChange}
                required
              />
            </div>

            <div className="row">
              <div className="col-md-6 mb-3">
                <label htmlFor="checkIn" className="form-label">Check-In Date</label>
                <input
                  type="date"
                  className="form-control"
                  id="checkIn"
                  name="checkIn"
                  value={bookingData.checkIn}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="col-md-6 mb-3">
                <label htmlFor="checkOut" className="form-label">Check-Out Date</label>
                <input
                  type="date"
                  className="form-control"
                  id="checkOut"
                  name="checkOut"
                  value={bookingData.checkOut}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="mb-4">
              <label htmlFor="numberOfGuests" className="form-label">Number of Guests</label>
              <input
                type="number"
                className="form-control"
                id="numberOfGuests"
                name="numberOfGuests"
                placeholder="Enter number of guests"
                value={bookingData.numberOfGuests}
                onChange={handleChange}
                required
              />
            </div>

            <div className="d-grid">
              <button type="submit" className="btn btn-primary btn-lg">Book Now</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default BookNow;
