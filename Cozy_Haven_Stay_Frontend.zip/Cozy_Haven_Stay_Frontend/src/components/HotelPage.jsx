import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import './HotelPage.css';

const HotelsPage = () => {
  const { city } = useParams();
  const [hotels, setHotels] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem('token');
    axios
      .get(`http://localhost:8000/api/hotels/city/${encodeURIComponent(city.trim())}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((res) => setHotels(res.data))
      .catch((err) => console.error('Error fetching hotels:', err));
  }, [city]);

  const defaultImage =
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80';

  const formatCityHeading = (name) =>
    name
      .split(' ')
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(' ');

  return (
    <div className="container py-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div className="w-100 text-center">
          <h2 className="city-heading">Hotels in {formatCityHeading(city)}</h2>
        </div>
        <div className="position-absolute end-0 me-3">
          <Link to="/search" className="btn btn-secondary">
            ← Back to Cities
          </Link>
        </div>
      </div>

      {hotels.length === 0 ? (
        <p className="text-center">No hotels found in {formatCityHeading(city)}.</p>
      ) : (
        <div className="row">
          {hotels.map((hotel) => (
            <div className="col-md-4 mb-4" key={hotel.id}>
              <div className="card h-100 shadow hotel-card">
                <img
                  src={hotel.imageUrl || defaultImage}
                  className="card-img-top hotel-img"
                  alt={hotel.name}
                  style={{ height: '200px', objectFit: 'cover' }}
                />
                <div className="card-body d-flex flex-column">
                  <h5 className="card-title">{hotel.name}</h5>
                  <p className="card-text text-secondary">{hotel.location}</p>
                  <p className="card-text text-danger">📞 {hotel.phoneno || 'Not Available'}</p>
                  <p className="card-text text-warning">
                    ⭐ Rating: {hotel.rating ?? (Math.random() * 2 + 3).toFixed(1)}
                  </p>
                  <Link
                    to={`/hotels/${hotel.id}/rooms`}
                    className="btn btn-outline-primary mt-auto"
                  >
                    View Rooms
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HotelsPage;
