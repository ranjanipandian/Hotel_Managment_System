import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import NotFound from './pages/NotFound';
import AboutPage from './pages/AboutPage';
import SearchPage from './pages/SearchPage';
import BookNow from './components/BookNow';
import Navbar from './components/Navbar';
import HotelPage from './components/HotelPage';
import RoomsPage from './components/RoomsPage';
import PaymentPage from './pages/PaymentPage';
import BookingPage from './pages/BookingPage';
import UserProfile from './components/UserProfile';

import AdminDashboard from './pages/AdminDashboard';
import AdminUsersManagement from './pages/AdminUsersManagement';
import AdminHotelManagement from './pages/AdminHotelManagement';
import EditHotel from './pages/EditHotel'; 
import AdminRoomManagement from './pages/AdminRoomManagement';
import AdminBookingManagement from './pages/AdminBookingManagement';
import AdminReviewModeration from './pages/AdminReviewModeration';
import AdminPaymentsPage from './pages/AdminPaymentsPage';
import AdminContactMessages from './pages/AdminContactMessages';

import OwnerDashboard from './pages/OwnerDashboard';
import OwnerHotelList from './pages/OwnerHotelList';
import OwnerManageRooms from './pages/OwnerManageRooms';
import OwnerViewBookings from './pages/OwnerViewBookings';
import OwnerEarnings from './pages/OwnerEarnings';
import OwnerReviewPage from './pages/OwnerReviewPage';
import OwnerAmenities from './pages/OwnerAmenities';
import OwnerManageImages from './pages/OwnerManageImages';
import AddHotel from './pages/AddHotel'; 

import './App.css';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <Router>
      <Navbar />
      <ToastContainer position="top-center" autoClose={2000} />
      <Routes>

        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/about" element={<AboutPage />} />

        <Route path="/search" element={
          <ProtectedRoute>
            <SearchPage />
          </ProtectedRoute>
        } />
        <Route path="/book" element={
          <ProtectedRoute>
            <BookNow />
          </ProtectedRoute>
        } />
        <Route path="/hotels/:city" element={
          <ProtectedRoute>
            <HotelPage />
          </ProtectedRoute>
        } />
        <Route path="/hotels/:hotelId/rooms" element={
          <ProtectedRoute>
            <RoomsPage />
          </ProtectedRoute>
        } />
        <Route path="/payments/:bookingId" element={
          <ProtectedRoute>
            <PaymentPage />
          </ProtectedRoute>
        } />
        <Route path="/book/:roomId" element={
          <ProtectedRoute>
            <BookingPage />
          </ProtectedRoute>
        } />
        <Route path="/profile" element={
          <ProtectedRoute>
            <UserProfile />
          </ProtectedRoute>
        } />

        <Route path="/admin-dashboard" element={
          <ProtectedRoute requiredRole="ADMIN">
            <AdminDashboard />
          </ProtectedRoute>
        } />
        <Route path="/admin/users" element={
          <ProtectedRoute requiredRole="ADMIN">
            <AdminUsersManagement />
          </ProtectedRoute>
        } />
        <Route path="/admin/hotels" element={
          <ProtectedRoute requiredRole="ADMIN">
            <AdminHotelManagement />
          </ProtectedRoute>
        } />
        <Route path="/admin/edit-hotel/:id" element={
          <ProtectedRoute requiredRole="ADMIN">
            <EditHotel />
          </ProtectedRoute>
        } />
        <Route path="/admin/rooms" element={
          <ProtectedRoute requiredRole="ADMIN">
            <AdminRoomManagement />
          </ProtectedRoute>
        } />
        <Route path="/admin/bookings" element={
          <ProtectedRoute requiredRole="ADMIN">
            <AdminBookingManagement />
          </ProtectedRoute>
        } />
        <Route path="/admin/reviews" element={
          <ProtectedRoute requiredRole="ADMIN">
            <AdminReviewModeration />
          </ProtectedRoute>
        } />
        <Route path="/admin/payments" element={
          <ProtectedRoute requiredRole="ADMIN">
            <AdminPaymentsPage />
          </ProtectedRoute>
        } />
        <Route path="/admin/contact-messages" element={
          <ProtectedRoute requiredRole="ADMIN">
            <AdminContactMessages />
          </ProtectedRoute>
        } />

        <Route path="/owner-dashboard" element={
          <ProtectedRoute requiredRole="OWNER">
            <OwnerDashboard />
          </ProtectedRoute>
        } />
        <Route path="/owner/my-hotels" element={
          <ProtectedRoute requiredRole="OWNER">
            <OwnerHotelList />
          </ProtectedRoute>
        } />
        <Route path="/owner/manage-rooms" element={
          <ProtectedRoute requiredRole="OWNER">
            <OwnerManageRooms />
          </ProtectedRoute>
        } />
        <Route path="/owner/edit-hotel/:id" element={
          <ProtectedRoute requiredRole="OWNER">
            <EditHotel />
          </ProtectedRoute>
        } />
        <Route path="/owner/edit-room/:id" element={
          <ProtectedRoute requiredRole="OWNER">
            <div>EditRoom Component Missing</div>
          </ProtectedRoute>
        } />
        <Route path="/owner/bookings" element={
          <ProtectedRoute requiredRole="OWNER">
            <OwnerViewBookings />
          </ProtectedRoute>
        } />
        <Route path="/owner/earnings" element={
          <ProtectedRoute requiredRole="OWNER">
            <OwnerEarnings />
          </ProtectedRoute>
        } />
        <Route path="/owner/reviews" element={
          <ProtectedRoute requiredRole="OWNER">
            <OwnerReviewPage />
          </ProtectedRoute>
        } />
        <Route path="/owner/amenities" element={
          <ProtectedRoute requiredRole="OWNER">
            <OwnerAmenities />
          </ProtectedRoute>
        } />
        <Route path="/owner/image-gallery" element={
          <ProtectedRoute requiredRole="OWNER">
            <OwnerManageImages />
          </ProtectedRoute>
        } />
        <Route path="/owner/add-hotel" element={
          <ProtectedRoute requiredRole="OWNER">
            <AddHotel />
          </ProtectedRoute>
        } />

        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
}

export default App;
